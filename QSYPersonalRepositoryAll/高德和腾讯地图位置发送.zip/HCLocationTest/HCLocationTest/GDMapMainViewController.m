//
//  GDMapMainViewController.m
//  GDMapMainViewController
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#import "GDMapMainViewController.h"

//地图
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <MAMapKit/MAMapKit.h>
//查询
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>
//定位相关
#import <AMapLocationKit/AMapLocationKit.h>


#import "MapTableViewCell.h"
#import "MapPoiTableView.h"
#import "SearchResultTableVC.h"


#define TITLE_HEIGHT                    64.f
#define CELL_COUNT                      5
#define CELL_HEIGHT                     55.f


@interface GDMapMainViewController ()<MAMapViewDelegate , MapPoiTableViewDelegate , AMapSearchDelegate  , UISearchBarDelegate ,SearchResultTableVCDelegate , UIAlertViewDelegate , AMapLocationManagerDelegate>

@property (nonatomic, strong) MAMapView *mapView;//地图

@property (nonatomic, strong) AMapSearchAPI *searchAPI;//查询

@property (nonatomic , strong) MapPoiTableView *tableView;//表视图

@property (nonatomic, strong) CLLocation * currentLocation;//获取坐标

@property (nonatomic, strong) AMapLocationManager *locationManager;//专属定位精度

@property (nonatomic , strong) CLLocationManager *MapLocationManager;//地图定位精度

@property (nonatomic, copy) NSString *userLongitude;//用户经度

@property (nonatomic, copy) NSString *userLatitude;//用户纬度

@property (nonatomic ,strong) MAPointAnnotation *annotation;//大头针

@property (nonatomic , strong) SearchResultTableVC *searchResultTableVC;

@end


@implementation GDMapMainViewController {
    // 高德API不支持定位开关，需要自己设置
   
    UIButton *_locationBtn;
    
    UIImage *_imageLocated;
    
    UIImage *_imageNotLocate;

    // 第一次定位标记

    BOOL isFirstLocated;
    
    // 禁止连续点击两次

    BOOL _isMapViewRegionChangedFromTableView;

    // 搜索页数
   
    NSInteger searchPage;
    
    UISearchController *_searchController;
    
    UITableView *_searchTableView;


}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
   [self.navigationController setNavigationBarHidden:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:YES];
    
}
- (void)viewDidLoad {
    
    [super viewDidLoad];

    self.title = @"具体位置";
    self.view.backgroundColor = [UIColor whiteColor];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleDone target:self action:@selector(returnBtn:)];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(sendBtn:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    //创建地图
    [self creatGDMap];
    
    //当前位置点
    [self initLocationButton];
    
    //创建表示图
    
    [self creatTableView];

    //创建搜索
    
    [self initSearch];
    //  创建定位
    [self creatLocation];
}

#pragma mark -- 返回按钮
- (void)returnBtn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
    [self.mapView setShowsUserLocation:NO];
}
#pragma mark -- 发送按钮
- (void)sendBtn:(UIButton *)btn {
    NSString *locationStr = [NSString stringWithFormat:@"获取对应用户经度：%@;获取对应用户维度：%@",self.userLongitude,self.userLatitude];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:locationStr delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

#pragma mark --创建定位
- (void)creatLocation {

     self.locationManager = [[AMapLocationManager alloc] init];

     self.locationManager.delegate = self;
    
    //设置允许后台定位参数，保持不会被系统挂起
    
    [self.locationManager setPausesLocationUpdatesAutomatically:NO];
    
    [self.locationManager setAllowsBackgroundLocationUpdates:NO];//iOS9(含)以上系统需设置    //开启持续定位

    //开始定位
    [self startSerialLocation];

}

#pragma  mark -- 开始定位

- (void)startSerialLocation {
    //开始定位
    [self.locationManager startUpdatingLocation];
}

#pragma mark -- 停止定位
- (void)stopSerialLocation {
    //停止定位
//    [self.locationManager stopUpdatingLocation];
}



#pragma mark -- 创建地图

- (void)creatGDMap {
    
    //创建地图并添加到父view上
    self.mapView = [[MAMapView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height*0.55)];

    self.mapView.showsCompass = NO;
    
    self.mapView.showsScale = NO;
    
    self.mapView.delegate = self;
    
    self.mapView.showsUserLocation = YES;
    
    [self.view addSubview:self.mapView];
    
    self.mapView.scrollEnabled = YES;
    
    //设置定位精度
    _MapLocationManager.desiredAccuracy=kCLLocationAccuracyKilometer;
    //追随用户模式
    
    [self.mapView setUserTrackingMode:MAUserTrackingModeNone  animated:YES];
    
    [self.mapView setZoomLevel:13.2 animated:NO];
    
    [self.view addSubview:self.mapView];
    

    //添加 大头针图片
    
    UIImageView *imageView = [[UIImageView alloc] init];
    
    UIImage *image = [UIImage imageNamed:@"coordinate"];

    imageView.image = image;
    imageView.frame = CGRectMake(self.view.frame.size.width/2-image.size.width/2, _mapView.bounds.size.height/2-image.size.height,
                                 image.size.width, image.size.height);
    imageView.center = CGPointMake(self.view.frame.size.width / 2, (CGRectGetHeight(_mapView.bounds) -  imageView.frame.size.height - TITLE_HEIGHT) * 0.5);
    [self.view addSubview:imageView];
    
    
}



#pragma mark 地图delegate

//地理位置更新后调用此方法
-(void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation updatingLocation:(BOOL)updatingLocation
{
    
    // 首次定位
    if (updatingLocation && !isFirstLocated) {
        [_mapView setCenterCoordinate:CLLocationCoordinate2DMake(userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude)];
        isFirstLocated = YES;
        NSLog(@"userlocation :%@", userLocation.location);
    }
    NSLog(@"userlocation :%@", userLocation.location);
}



//错误回调
-(void)searchRequest:(id)request didFailWithError:(NSError *)error {
   
    NSLog(@"request%@  error%@",request,error);
    if ([error.domain isEqualToString:@"AMapSearchErrorDomain"]) {
//        [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(zaiciqingqiu) userInfo:nil repeats:YES];
    }

}

- (void)mapView:(MAMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    MACoordinateRegion region;
    CLLocationCoordinate2D centerCoordinate = mapView.region.center;
    self.userLongitude = [NSString stringWithFormat:@"%f",centerCoordinate.longitude];
    self.userLatitude = [NSString stringWithFormat:@"%f",centerCoordinate.latitude];
    region.center = centerCoordinate;
    
    if (!_isMapViewRegionChangedFromTableView && isFirstLocated) {
        
        AMapGeoPoint *point = [AMapGeoPoint locationWithLatitude:_mapView.centerCoordinate.latitude longitude:
                               _mapView.centerCoordinate.longitude];
       
        [self searchReGeocodeWithAMapGeoPoint:point];
        
        [self searchPoiByAMapGeoPoint:point];
        
        // 范围移动时当前页面数重置
        searchPage = 1;
    }
    
    _isMapViewRegionChangedFromTableView = NO;

}

- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation {
    if ([annotation isKindOfClass:[MAPointAnnotation class]]) {
       
        static NSString *reuseIndetifier = @"anntationReuseIndetifier";
        
        MAAnnotationView *annotationView = (MAAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:reuseIndetifier];
       
        if (!annotationView) {
        
            annotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:reuseIndetifier];
           
            annotationView.image = [UIImage imageNamed:@"msg_location"];
            
            annotationView.centerOffset = CGPointMake(0, -18);
        
        }
        
        return annotationView;
    
    }
    
    return nil;

}

- (void)mapView:(MAMapView *)mapView didAddAnnotationViews:(NSArray *)views
{
    MAAnnotationView *view = views[0];
    
    // 放到该方法中用以保证userlocation的annotationView已经添加到地图上了。
    if ([view.annotation isKindOfClass:[MAUserLocation class]])
    {
        MAUserLocationRepresentation *pre = [[MAUserLocationRepresentation alloc] init];
        pre.showsAccuracyRing = NO;
        [_mapView updateUserLocationRepresentation:pre];
        
        view.calloutOffset = CGPointMake(0, 0);
    }
}


#pragma mark - MapPoiTableViewDelegate
- (void)loadMorePOI {
    searchPage++;
    AMapGeoPoint *point = [AMapGeoPoint locationWithLatitude:_mapView.centerCoordinate.latitude longitude:
                           _mapView.centerCoordinate.longitude];
    [self searchPoiByAMapGeoPoint:point];

}



- (void)setMapCenterWithPOI:(AMapPOI *)point isLocateImageShouldChange:(BOOL)isLocateImageShouldChange {
    
    // 切换定位图标
    if (isLocateImageShouldChange) {
    
        [_locationBtn setImage:_imageNotLocate forState:UIControlStateNormal];
    
    }
    
    _isMapViewRegionChangedFromTableView = YES;
    
    CLLocationCoordinate2D location = CLLocationCoordinate2DMake(point.location.latitude, point.location.longitude);
    
    [_mapView setCenterCoordinate:location animated:YES];
    
    NSLog(@"获取到对应tab列表的：name ==== %@ , Address === %@   lattiude === %.6f , longitude === %.6f" ,point.name ,point.address , point.location.latitude , point.location.longitude);
    //回传所选中地理位置数据
    if (self.geographicPositionCallBackBlock) {
        
     self.geographicPositionCallBackBlock(point.name , [NSString stringWithFormat:@"%@%@%@%@",point.province,point.city,point.district,point.address] ,point.location.longitude  , point.location.latitude);
        
    };
    
    if (self.goScopMapInFoBlock) {
        NSString *longitude = [NSString stringWithFormat:@"%f",point.location.longitude];
        NSString *latitude = [NSString stringWithFormat:@"%f",point.location.latitude];
        NSDictionary *params = @{@"name":point.name,@"address":[NSString stringWithFormat:@"%@%@%@%@",point.province,point.city,point.district,point.address],@"longitude":longitude,@"latitude":latitude};
        self.goScopMapInFoBlock(params);
    }
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)setSendButtonEnabledAfterLoadFinished {
    self.navigationItem.rightBarButtonItem.enabled = YES;
}

- (void)setCurrentCity:(NSString *)city
{
    [_searchResultTableVC setSearchCity:city];
}


#pragma mark - UISearchBarDelegate

#pragma mark - SearchResultTableVCDelegate

- (void)setSelectedLocationWithLocation:(AMapPOI *)poi
{
    [_mapView setCenterCoordinate:CLLocationCoordinate2DMake(poi.location.latitude,poi.location.longitude) animated:NO];
    _searchController.searchBar.text = @"";
}

#pragma mark -- 定位点
- (void)initLocationButton {

    _imageLocated = [UIImage imageNamed:@"gpssearchbutton"];
    
    _imageNotLocate = [UIImage imageNamed:@"gpsnormal"];
    
    _locationBtn = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetWidth(_mapView.bounds)-50, CGRectGetHeight(_mapView.bounds)-50, 40, 40)];
    
    
    _locationBtn.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    
    _locationBtn.backgroundColor = [UIColor colorWithRed:239.0/255 green:239.0/255 blue:239.0/255 alpha:1];
    
    _locationBtn.layer.cornerRadius = 3;
    
    [_locationBtn addTarget:self action:@selector(actionLocation) forControlEvents:UIControlEventTouchUpInside];
    
    [_locationBtn setImage:_imageNotLocate forState:UIControlStateNormal];
    
    [self.view addSubview:_locationBtn];
}

- (void)actionLocation {
    
    //定位到当前位置
    [_mapView setCenterCoordinate:_mapView.userLocation.coordinate animated:YES];

}


#pragma mark -- 定位代理方法

- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location {
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
}

#pragma mark -- 创建表示图
- (void)creatTableView {
    
    _tableView = [[MapPoiTableView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_mapView.frame)-64, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height*0.45)];
    
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
}



//查询相关

- (void)initSearch{
   
    searchPage = 1;
    
    _searchAPI = [[AMapSearchAPI alloc] init];
    
    _searchAPI.delegate = _tableView;

    _searchResultTableVC = [[SearchResultTableVC alloc] init];
    
    _searchResultTableVC.delegate = self;
    
    _searchController = [[UISearchController alloc] initWithSearchResultsController:_searchResultTableVC];
    
    _searchController.searchBar.placeholder = @"小区/写字楼/学校等";
    
    _searchController.searchResultsUpdater = _searchResultTableVC;
    
    [self.view addSubview:_searchController.searchBar];
    
    _searchController.searchBar.delegate = self;
    
    // 解决searchbar无法置顶的问题
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
}

// 搜索逆向地理编码-AMapGeoPoint

- (void)searchReGeocodeWithAMapGeoPoint:(AMapGeoPoint *)location
{
    AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
    regeo.location = location;
    // 返回扩展信息
    regeo.requireExtension = YES;
    [_searchAPI AMapReGoecodeSearch:regeo];
}

// 搜索中心点坐标周围的POI-AMapGeoPoint

- (void)searchPoiByAMapGeoPoint:(AMapGeoPoint *)location
{
    AMapPOIAroundSearchRequest *request = [[AMapPOIAroundSearchRequest alloc] init];
    request.location = location;
    // 搜索半径
    request.radius = 1000;
    // 搜索结果排序
    request.sortrule = 1;
    // 当前页数
    request.page = searchPage;
    
    [_searchAPI AMapPOIAroundSearch:request];
}
//mapview 错误回调
- (void)mapView:(MAMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
   
    switch([error code]) {
    
        case kCLErrorDenied: {
        
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"定位失败" message:@"请在手机设置中开启定位功能\n开启步骤:设置 > 隐私 > 位置 > 定位服务下《神工007》应用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            
            alertView.delegate = self;
            
            [alertView setTag:3461331];
            
            [alertView show];
            
            break ;
        
        }
            
            default:
            
            break;
    
    }

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (alertView.tag == 3461331){
       
        if (buttonIndex == 0) {
        
            [self.navigationController popViewControllerAnimated:YES];
            //        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"prefs:root=LOCATION_SERVICES"]];
        }
    
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
