//
//  APIKey.h
//  HCLocationTest
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#ifndef HCLocationAPIKey_h
#define HCLocationAPIKey_h

const static NSString *APIKey = @"67f13782223a26675f01611d033924e9";
#endif /* HCLocationAPIKey_h */
