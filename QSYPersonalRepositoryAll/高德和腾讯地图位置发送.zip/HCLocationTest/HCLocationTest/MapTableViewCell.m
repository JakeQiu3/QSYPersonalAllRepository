//
//  MapTableViewCell.m
//  MapTableViewCell
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#import "MapTableViewCell.h"

@interface MapTableViewCell ()

@property (nonatomic , strong) UIImageView *imageView1;//位置图标

@property (nonatomic , strong) UILabel *oneStairLabel;//一级地址

@property (nonatomic , strong) UILabel *twoStairLabel;//二级地址

//定义一个contentLabel文本高度的属性
@property (nonatomic,assign) CGFloat contentLabelH;

@property (nonatomic,assign) CGFloat contentLabelH2;

@property (nonatomic , copy) NSString * name;

@property (nonatomic , copy) NSString * address;

@end


@implementation MapTableViewCell


-(void)dealloc {
    
    _imageView1 = nil;
    
    _oneStairLabel = nil;
    
    _twoStairLabel = nil;
    
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubviews];
    }
    return self;
    
}

- (void)initSubviews {
    
    
    _imageView1 = [[UIImageView alloc] init];
    
    _imageView1.image = [UIImage imageNamed:@"333"];
    _imageView1.frame = CGRectMake(20, 10, 15, 20);
    
    [self.contentView addSubview:_imageView1];

    _oneStairLabel = [[UILabel alloc] init];
    
    _oneStairLabel.text = @"福马大厦";
    
    _oneStairLabel.textColor = [UIColor blackColor];
    
    _oneStairLabel.alpha = 0.8;
    
    _oneStairLabel.textAlignment = NSTextAlignmentLeft;
    
    _oneStairLabel.font = [UIFont systemFontOfSize:14.0f];
    
    _oneStairLabel.numberOfLines = 0;
    
    _oneStairLabel.frame = CGRectMake(20, _imageView1.bounds.size.width-10,15, 20);
    [self.contentView addSubview:_oneStairLabel];
    
    
    
    _twoStairLabel = [[UILabel alloc] init];
    
    _twoStairLabel.text = @"的电风扇的范德萨范德萨发送到发送到";
    
    _twoStairLabel.textAlignment = NSTextAlignmentLeft;
    
    _twoStairLabel.textColor = [UIColor colorWithRed:0.8334 green:0.8334 blue:0.8334 alpha:1.0];
    
    _twoStairLabel.font = [UIFont systemFontOfSize:13.0f];
    
    _twoStairLabel.numberOfLines = 0;
    
    [self.contentView addSubview:_twoStairLabel];
    _oneStairLabel.frame = CGRectMake(CGRectGetMaxX(_imageView1.frame)+5, _imageView1.bounds.origin.y, self.bounds.size.width-CGRectGetMaxX(_imageView1.frame)+15, 15);
    _twoStairLabel.frame = CGRectMake(CGRectGetMaxX(_imageView1.frame)+5, CGRectGetMaxY(_oneStairLabel.frame), self.bounds.size.width-CGRectGetMaxX(_imageView1.frame)+15, 15);
}

- (void)configLocalityDataWithName:(NSString *)name address:(NSString *)address {
    
    _oneStairLabel.text = name;
    
    _twoStairLabel.text = address;
    
}

//在表格cell中 计算出高度
-(CGFloat)rowHeightWithCellName:(NSString *)name andAddress:(NSString *)address
{
    self.name = name;
    self.address = address;
    
    //    设置标签的高度
    CGRect oneNewRect = self.oneStairLabel.frame;
    oneNewRect.size.height = self.contentLabelH;
    self.oneStairLabel.frame = oneNewRect;
    
    //    更新约束
    [self.oneStairLabel layoutIfNeeded];
    
    //3.  视图的最大 Y 值
    CGFloat h= self.oneStairLabel.frame.size.height;
    
    //  设置标签的高度
    CGRect twoNewRect = self.twoStairLabel.frame;
    twoNewRect.size.height = self.contentLabelH2;
    self.twoStairLabel.frame = twoNewRect;
    
    // 2. 更新约束
    [self.twoStairLabel layoutIfNeeded];
    
    //    3.  视图的最大 Y 值
    CGFloat t= self.twoStairLabel.frame.size.height;
    
    return h+t+5; //最大的高度
}

/*
 *  懒加载的方法返回contentLabel的高度  (只会调用一次)
 */
- (CGFloat)contentLabelH {
    if(!_contentLabelH){
        CGFloat h=[self.name boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width-20, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil].size.height;
        
        _contentLabelH = h;
        
    }
    
    return _contentLabelH;
}

- (CGFloat)contentLabelH2{
    if(!_contentLabelH2){
        CGFloat t=[self.address boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width-20, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size.height;
        _contentLabelH2 = t;
    }
    return _contentLabelH2;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
