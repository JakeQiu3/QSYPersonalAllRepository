//
//  GDMapMainViewController.h
//  GDMapMainViewController
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^GeographicPositionCallBackBlock)(NSString *name , NSString *address , CGFloat longitude , CGFloat latitude);


// 字典描述信息
typedef void (^ScopMapBlock)(NSDictionary *mapSrc);

@interface GDMapMainViewController : UIViewController

/**
 *  回传地理位置 经纬度 block
 */
@property (nonatomic , copy ) GeographicPositionCallBackBlock geographicPositionCallBackBlock;

// 返回位置信息
@property (nonatomic, copy) ScopMapBlock  goScopMapInFoBlock;


@end
