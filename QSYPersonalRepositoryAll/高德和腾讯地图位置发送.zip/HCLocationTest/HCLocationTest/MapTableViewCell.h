//
//  MapTableViewCell.h
//  MapTableViewCell
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapTableViewCell : UITableViewCell

/**
 *  设置地理位置数据
 *
 *  @param name    名称
 *  @param address 地址
 */
- (void)configLocalityDataWithName:(NSString *)name address:(NSString *)address;

-(CGFloat)rowHeightWithCellName:(NSString *)name andAddress:(NSString *)address;
@end
