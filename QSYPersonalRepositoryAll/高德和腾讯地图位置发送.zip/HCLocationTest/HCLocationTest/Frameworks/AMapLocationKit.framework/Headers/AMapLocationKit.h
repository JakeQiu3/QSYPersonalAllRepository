//
//  AMapLocationKit.h
//  AMapLocationKit
//
//  Created by AutoNavi on 15/10/22.
//  Copyright © 2015年 Amap. All rights reserved.
//

#import <AMapLocationKit/AMapLocationVersion.h>

#import <AMapLocationKit/AMapLocationManager.h>
#import <AMapLocationKit/AMapLocationCommonObj.h>
#import <AMapLocationKit/AMapLocationRegionObj.h>

#import <AMapLocationKit/AMapGeoFenceRegionObj.h>
#import <AMapLocationKit/AMapGeoFenceManager.h>
#import <AMapLocationKit/AMapGeoFenceError.h>
