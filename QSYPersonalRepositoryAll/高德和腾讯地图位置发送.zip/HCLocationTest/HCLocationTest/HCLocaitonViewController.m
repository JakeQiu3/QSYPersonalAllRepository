//
//  HCLocaitonViewController.m
//  HCLocaitonViewController
//
//  Created by 7lk on 2017/10/10.
//  Copyright © 2017年 7lk. All rights reserved.
//

#import "HCLocaitonViewController.h"
#import "GDMapMainViewController.h"
@interface HCLocaitonViewController ()

@end

@implementation HCLocaitonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sendBtn.frame = CGRectMake(150, 100, 100, 40);
//    sendBtn.backgroundColor = [UIColor lightGrayColor];
    [sendBtn setTitle:@"发送位置" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    sendBtn.showsTouchWhenHighlighted = YES;
    [sendBtn addTarget:self action:@selector(sendLocation:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sendBtn];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)sendLocation:(UIButton *)btn {
    GDMapMainViewController *mapView = [[GDMapMainViewController alloc] init];
    [self.navigationController pushViewController:mapView animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
