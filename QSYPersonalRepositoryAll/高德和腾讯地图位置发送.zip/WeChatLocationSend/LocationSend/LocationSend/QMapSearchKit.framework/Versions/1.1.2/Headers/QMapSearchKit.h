//
//  QMapSearchKit.h
//  QMapSearchKit
//
//  Created by xfang on 14/11/12.
//  Copyright (c) 2014年 tencent. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "QMSSearchServices.h"
#import "QMSSearcher.h"