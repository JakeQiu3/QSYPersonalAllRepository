//
//  ViewController.h
//  LocationSend
//
//  Created by ShaoFeng on 16/9/6.
//  Copyright © 2016年 Cocav. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

