# 博客地址:http://blog.csdn.net/feng2qing?viewmode=list
# 实现微信发送位置效果
## 功能简介:
### 定位当前位置,支持拖拽,缩放
### 搜索当前位置附近建筑,地铁,酒店...
### 手动拖动地图进行位置选择,搜索制定位置附近建筑,地铁,酒店,并且可以上拉加载
### 一键回到当前位置
### 将当前位置或制定位置发送

# DEMO效果
![Mou icon](http://g.recordit.co/Br2vv3DWd1.gif)

