//
//  TempView.m
//  ACameraDemo
//
//  Created by 王博 on 15/8/6.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import "TempView.h"
#import <AVFoundation/AVFoundation.h>

@implementation TempView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
    CGContextRef con = UIGraphicsGetCurrentContext();
    for (AVMetadataObject * obj in self.faces) {
        if ([obj isKindOfClass:[AVMetadataFaceObject class]]) {
            AVMetadataFaceObject * face = (AVMetadataFaceObject *)obj;
            //CGContextRotateCTM(con, face.yawAngle);
            CGContextAddRect(con, [self faceBoundsFrom:face.bounds]);
            //CGContextRotateCTM(con, 0);
            NSLog(@"%@", NSStringFromCGRect(face.bounds));
        }
    }
    //CGContextAddEllipseInRect(con, CGRectMake(0, 0, 50, 50));
    //CGContextSetFillColorWithColor(con, [UIColor blueColor].CGColor);
    //CGContextFillPath(con);
    CGContextSetStrokeColorWithColor(con, [UIColor blueColor].CGColor);
    CGContextStrokePath(con);
}

- (CGRect)faceBoundsFrom:(CGRect)bounds {
    CGRect newBounds = CGRectZero;
    newBounds.origin.x = (1 - bounds.origin.y) * self.bounds.size.width - 50;
    newBounds.origin.y = bounds.origin.x * self.bounds.size.height - 50;
    newBounds.size.width = bounds.size.width * self.bounds.size.width;
    newBounds.size.height = bounds.size.height * self.bounds.size.height;
    
    return newBounds;
}

@end
