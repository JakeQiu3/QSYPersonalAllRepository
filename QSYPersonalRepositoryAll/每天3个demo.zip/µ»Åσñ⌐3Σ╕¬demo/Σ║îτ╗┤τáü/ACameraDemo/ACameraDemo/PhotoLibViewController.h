//
//  PhotoLibViewController.h
//  ACameraDemo
//
//  Created by 王博 on 15/8/5.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoLibViewController : UITableViewController

@end
