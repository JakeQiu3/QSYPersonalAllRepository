//
//  PhotoViewController.m
//  ACameraDemo
//
//  Created by 王博 on 15/8/5.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import "PhotoViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "PhotoCell.h"
#import "EBPhotoPagesController.h"

@interface PhotoViewController () <UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, EBPhotoPagesDataSource, EBPhotoPagesDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) EBPhotoPagesController * photoPagesController;

@end

@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSInteger count = [self.assetsGroup numberOfAssets];
    //NSLog(@"count %ld", count);
    return count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PhotoCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"photoCell" forIndexPath:indexPath];
    __block ALAsset * asset = nil;
    [self.assetsGroup enumerateAssetsAtIndexes:[NSIndexSet indexSetWithIndex:indexPath.item] options:NSEnumerationConcurrent usingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
        if (result) {
            asset = result;
            *stop = YES;
        } else {
            cell.photoView.image = [UIImage imageWithCGImage:[asset thumbnail]];
        }
    }];
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    self.photoPagesController = [[EBPhotoPagesController alloc] initWithDataSource:self delegate:self photoAtIndex:indexPath.item];
    [self.navigationController pushViewController:self.photoPagesController animated:YES];
}

- (BOOL)photoPagesController:(EBPhotoPagesController *)photoPagesController
    shouldExpectPhotoAtIndex:(NSInteger)index {
    if (index >=0 && index < [self.assetsGroup numberOfAssets]) {
        return YES;
    } else {
        return NO;
    }
}

- (void)photoPagesController:(EBPhotoPagesController *)controller
                imageAtIndex:(NSInteger)index
           completionHandler:(void(^)(UIImage *image))handler {
    __block ALAsset * asset = nil;
    [self.assetsGroup enumerateAssetsAtIndexes:[NSIndexSet indexSetWithIndex:index] options:NSEnumerationConcurrent usingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
        if (result) {
            asset = result;
            *stop = YES;
        } else {
            CGImageRef ref = asset.defaultRepresentation.fullScreenImage;
            UIImage *img = [[UIImage alloc]initWithCGImage:ref];
            handler(img);
        }
    }];
}

//- (BOOL)photoPagesController:(EBPhotoPagesController *)photoPagesController shouldAllowDeleteForPhotoAtIndex:(NSInteger)index {
//    
//    return YES;
//}
//
//- (void)photoPagesController:(EBPhotoPagesController *)photoPagesController
//       didDeletePhotoAtIndex:(NSInteger)index {
//    __block ALAsset * asset = nil;
//    [self.assetsGroup enumerateAssetsAtIndexes:[NSIndexSet indexSetWithIndex:index] options:NSEnumerationConcurrent usingBlock:^(ALAsset *result, NSUInteger index, BOOL *stop) {
//        if (result) {
//            asset = result;
//            *stop = YES;
//        } else {
//            if(asset.isEditable) {
//                
//            }
//        }
//    }];
//}

@end
