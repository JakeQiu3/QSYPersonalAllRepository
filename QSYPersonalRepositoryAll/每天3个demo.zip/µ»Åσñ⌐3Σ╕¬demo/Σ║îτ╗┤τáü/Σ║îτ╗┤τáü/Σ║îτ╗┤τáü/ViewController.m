//
//  ViewController.m
//  二维码
//
//  Created by qianfeng on 15/9/28.
//  Copyright (c) 2015年 樊 运育. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()<AVCaptureMetadataOutputObjectsDelegate,UIAlertViewDelegate>

@property(nonatomic,strong)UIImageView *lineView ;
@property(nonatomic,assign)BOOL isUp;
@property(nonatomic,strong)AVCaptureSession *session ;
@property(nonatomic,strong)CADisplayLink *displayLink ;
@property(nonatomic,strong) AVCaptureVideoPreviewLayer *layer ;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createUI];

}

-   (void)createUI{
    UIImageView*imgView = [ [UIImageView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    imgView.image = [UIImage imageNamed:@"HR_border"];
    [self.view addSubview:imgView];
    
    //创建扫描线
    UIImageView*lineView = [[ UIImageView alloc] initWithFrame:CGRectMake(100, 100, 100, 10)];
    lineView.image = [UIImage imageNamed:@"HR_scan_line"];
    _lineView = lineView;
    [self.view addSubview: _lineView];
    
    _displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(showAnim)];
    [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
    
}
//动画
-   (void)showAnim{
    CGFloat lineY = _lineView.frame.origin.y;

    if (_isUp) {
        lineY --;
        _lineView.transform = CGAffineTransformMakeRotation(M_PI);
    }else{
        lineY ++ ;
        _lineView.transform = CGAffineTransformMakeRotation(0);//相对于原来的偏转
       //   _lineView.transform = CGAffineTransformIdentity;   //取消所有效果
    }
    if (lineY >190) {
        _isUp = YES;
    }else if(lineY < 100){
        _isUp = NO;
    }
    
    _lineView.frame = CGRectMake(100, lineY, 100, 10);
}
//添加二维码
-   (void)createQrCode{
    //1、拿到输入设备
    AVCaptureDevice*device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    //2、设置输入
    NSError *error = nil;
    
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    
    if (error) {
        NSLog(@"未发现摄像头");
    }else{
        //3、设置输出
        AVCaptureMetadataOutput *output = [ [AVCaptureMetadataOutput alloc] init];
        // 设置输出回调
        [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
        
        //4、创建会话
        _session = [ [AVCaptureSession alloc] init ] ;
        //添加输入
        [_session addInput:input];
        //输出
        [_session addOutput:output];
        
        //5、设置输出格式（扫描识别格式）
        [output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
        
        //6、增加透视层
        _layer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:_session];
        _layer.frame = self.view.bounds;
        [self.view.layer insertSublayer:_layer atIndex:0];
        
        //7、开始扫描
        [_session startRunning];

    }
    
}

-   (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
    if (metadataObjects.count >0) {
        [_session stopRunning];
        _displayLink.paused = YES;
        [_layer removeFromSuperlayer];
        
        AVMetadataMachineReadableCodeObject*obj = [metadataObjects lastObject];
        NSString *string = obj.stringValue ;
        
        //@"tecent:www.baidu.com"
        UIAlertView*alert = [ [UIAlertView alloc] initWithTitle:@"扫描结果" message:string delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消",nil];
        [alert show];
    }
}

//alert的代理方法
-   (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            [_session startRunning];
            _displayLink.paused = NO;
            [self.view.layer insertSublayer:_layer atIndex:0];
        }
            break;
            
            case 1:
        default:
            break;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
