//
//  TempView.h
//  ACameraDemo
//
//  Created by 王博 on 15/8/6.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TempView : UIView

@property (nonatomic) NSArray * faces;

@end
