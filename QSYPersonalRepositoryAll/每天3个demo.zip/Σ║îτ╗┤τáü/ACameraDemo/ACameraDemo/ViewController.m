//
//  ViewController.m
//  ACameraDemo
//
//  Created by 王博 on 15/8/4.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <CoreImage/CoreImage.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "TempView.h"

@interface ViewController () <AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureSession * _captureSession;
    CALayer * _previewLayer;
    CIContext * _context;
    CIFilter * _currentFilter;
    ALAssetsLibrary * _assetsLibrary;
    BOOL _captureFlag;
    
}
- (IBAction)captureAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *captureButton;
@property (weak, nonatomic) IBOutlet TempView *tempView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _assetsLibrary = [[ALAssetsLibrary alloc] init];
    
    _context = [CIContext contextWithEAGLContext:[[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2]];
    
    // Device
    AVCaptureDevice * device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    // Input
    AVCaptureDeviceInput * input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    // Output
    AVCaptureVideoDataOutput * videoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
    [videoDataOutput setSampleBufferDelegate:self queue:dispatch_queue_create("VideoQueue", DISPATCH_QUEUE_SERIAL)];
    AVCaptureMetadataOutput * metadataOutput = [[AVCaptureMetadataOutput alloc] init];
    [metadataOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    // Session
    _captureSession = [[AVCaptureSession alloc] init];
    [_captureSession setSessionPreset:AVCaptureSessionPresetHigh];
    if ([_captureSession canAddInput:input])
    {
        [_captureSession addInput:input];
    }
    if ([_captureSession canAddOutput:videoDataOutput])
    {
        [_captureSession addOutput:videoDataOutput];
    }
    if ([_captureSession canAddOutput:metadataOutput])
    {
        [_captureSession addOutput:metadataOutput];
        if ([metadataOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeFace]) {
            [metadataOutput setMetadataObjectTypes:@[AVMetadataObjectTypeFace]];
        }
    }
    // Preview
//    _previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_captureSession];
//    _previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
//    _previewLayer.frame = self.view.layer.bounds;
//    [self.view.layer insertSublayer:_previewLayer atIndex:0];
    
    _previewLayer = [CALayer layer];
    _previewLayer.backgroundColor = [UIColor blackColor].CGColor;
    _previewLayer.frame = CGRectMake(0, 0, self.view.bounds.size.height, self.view.bounds.size.width);
    _previewLayer.affineTransform = CGAffineTransformMakeRotation(M_PI / 2.0);
    _previewLayer.position = self.view.center;
    [self.view.layer insertSublayer:_previewLayer atIndex:0];
    NSLog(@"%@", NSStringFromCGRect(_previewLayer.frame));
    
    //_currentFilter = [CIFilter filterWithName:@"CIColorInvert"];
}

- (void)viewWillAppear:(BOOL)animated {
    // Start
    self.navigationController.navigationBarHidden = YES;
    [_captureSession startRunning];
}

- (void)viewWillDisappear:(BOOL)animated {
    [_captureSession stopRunning];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    CIImage * ciImage = [CIImage imageWithCVPixelBuffer:imageBuffer];
    
    if (_currentFilter) {
        [_currentFilter setValue:ciImage forKey:kCIInputImageKey];
        ciImage = _currentFilter.outputImage;
    }
    CGImageRef cgImage = [_context createCGImage:ciImage fromRect:ciImage.extent];
    dispatch_async(dispatch_get_main_queue(), ^{
        void *p = (__bridge void *)_previewLayer.contents;
        _previewLayer.contents = (__bridge id)(cgImage);
        CGImageRelease(p);
    });
    
    if (_captureFlag) {
        [_captureSession stopRunning];
        _captureFlag = NO;
        
        ALAssetOrientation assetOrientation = ALAssetOrientationRight;
        switch ([UIDevice currentDevice].orientation) {
                
            case UIDeviceOrientationLandscapeLeft:
                assetOrientation = ALAssetOrientationUp;
                break;
            case UIDeviceOrientationLandscapeRight:
                assetOrientation = ALAssetOrientationDown;
                break;
                
            default:
                assetOrientation = ALAssetOrientationRight;
                break;
        }
        [_assetsLibrary writeImageToSavedPhotosAlbum:cgImage orientation:assetOrientation completionBlock:^(NSURL *assetURL, NSError *error) {
            if (error) {
                NSLog(@"%@", error);
            } else {
                NSLog(@"%@", assetURL);
            }
            [_captureSession startRunning];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.captureButton.enabled = YES;
            });
        }];
    }
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    //<AVMetadataFaceObject: 0x170221f40, faceID=4, bounds={0.3,0.3 0.2x0.3}, rollAngle=270.0, yawAngle=45.0, time=187822579683916>
    self.tempView.faces = metadataObjects;
    [self.tempView setNeedsDisplay];
    
}

- (IBAction)captureAction:(UIButton *)sender {
    _captureFlag = YES;
    sender.enabled = NO;
}

@end
