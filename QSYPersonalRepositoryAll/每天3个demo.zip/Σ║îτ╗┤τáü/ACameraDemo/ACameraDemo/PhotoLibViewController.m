//
//  PhotoLibViewController.m
//  ACameraDemo
//
//  Created by 王博 on 15/8/5.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import "PhotoLibViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "PhotoViewController.h"

@interface PhotoLibViewController ()
{
    ALAssetsLibrary * _assetsLibrary;
    NSMutableArray * _groupArray;
}

@end

@implementation PhotoLibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _groupArray = [NSMutableArray array];
    _assetsLibrary = [[ALAssetsLibrary alloc] init];
    [_assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
        if (group) {
            [_groupArray addObject:group];
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
    } failureBlock:^(NSError *error) {
        NSLog(@"Group not found!\n");
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _groupArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    ALAssetsGroup * group = _groupArray[indexPath.row];
    cell.textLabel.text = [group valueForProperty:ALAssetsGroupPropertyName];
    cell.imageView.image = [UIImage imageWithCGImage:[group posterImage]];
    
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"ToPhotoVC"]) {
        PhotoViewController * vc = [segue destinationViewController];
        NSIndexPath * indexpath = [self.tableView indexPathForCell:sender];
        vc.assetsGroup = _groupArray[indexpath.row];
    }
}


@end
