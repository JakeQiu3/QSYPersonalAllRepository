//
//  LoginModle.m
//  QSYPersonalRepositoryAll
//
//  Created by qsyMac on 16/6/12.
//  Copyright © 2016年 QSY. All rights reserved.
//

#import "LoginModle.h"

@implementation LoginModle

@end
