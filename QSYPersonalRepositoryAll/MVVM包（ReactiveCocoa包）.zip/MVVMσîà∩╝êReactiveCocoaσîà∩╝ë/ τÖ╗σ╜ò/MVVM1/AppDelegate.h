//
//  AppDelegate.h
//  MVVM1
//
//  Created by 邱少依 on 16/10/11.
//  Copyright © 2016年 QSY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

