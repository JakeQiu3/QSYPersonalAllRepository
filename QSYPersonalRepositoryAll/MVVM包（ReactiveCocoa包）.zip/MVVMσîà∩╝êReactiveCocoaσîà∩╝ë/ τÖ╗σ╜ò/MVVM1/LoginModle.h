//
//  LoginModle.h
//  QSYPersonalRepositoryAll
//
//  Created by qsyMac on 16/6/12.
//  Copyright © 2016年 QSY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginModle : NSObject

@property (nonatomic, copy)NSString *name;
@property (nonatomic, copy)NSString *password;
@property (nonatomic, copy)NSString *confirmword;

@end
