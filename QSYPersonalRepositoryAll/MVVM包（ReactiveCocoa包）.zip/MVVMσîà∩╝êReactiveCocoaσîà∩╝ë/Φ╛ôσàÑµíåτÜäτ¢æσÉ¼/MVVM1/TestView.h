//
//  TestView.h
//  QSYPersonalRepositoryAll
//
//  Created by qsyMac on 16/6/10.
//  Copyright © 2016年 QSY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestView : UIView
- (void)btnClick:(id)x;
@end
