//
//  BlockViewController.m
//  ReactiveCocoaUtilityDemo
//
//  Created by TangJR on 10/21/15.
//  Copyright © 2015 tangjr. All rights reserved.
//

#import "BlockViewController.h"
#import "ReactiveCocoa.h"

@interface BlockViewController ()

@end

@implementation BlockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupRequestSignal];
}

- (void)setupRequestSignal {
    
    // 假设发起两个请求：signal1 执行完后，再执行signal2
    // request1与request2是自定义方法，会返回两个信号
    RACSignal *signal1 = [self request1];
    RACSignal *signal2 = [self request2];
    RACSignal *signal3 = [self request3];

//  concat拼接方法，这个方法会在第一个信号sendNext之后，才会激活第二个信号，从而达到有序触发的目的。
    [[signal1 concat:signal2] subscribeNext:^(id x) {
        
        NSLog(@"%@", x);
    }];
//  发起多个请求,直到所有请求都完成后，获取到最终的结果: merge 或者 combineLatest方法
    [[signal1 merge:signal2] subscribeNext:^(id x) {
        NSLog(@"%@", x);
    }];
}

- (RACSignal *)request1 {
    
    return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [subscriber sendNext:@"请求1完成"];
            [subscriber sendCompleted];
        });
        
        return nil;
    }];
}

- (RACSignal *)request2 {
    
    return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [subscriber sendNext:@"请求2完成"];
            [subscriber sendCompleted];
        });
        
        return nil;
    }];
}

- (RACSignal *)request3 {
    return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(DISPATCH_TIME_NOW * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [subscriber sendNext:@"请求3完成"];
            [subscriber sendCompleted];
        });
        return nil;
    }];
}
@end