//
//  DetailViewController.h
//  DQKFreezeWindowView
//
//  Created by 宋宋 on 15/7/18.
//  Copyright © 2015年 dianqk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
