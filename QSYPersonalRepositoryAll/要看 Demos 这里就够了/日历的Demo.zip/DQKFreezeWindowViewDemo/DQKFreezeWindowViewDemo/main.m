//
//  main.m
//  DQKFreezeWindowViewDemo
//
//  Created by 宋宋 on 15/7/19.
//  Copyright © 2015年 dianqk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
