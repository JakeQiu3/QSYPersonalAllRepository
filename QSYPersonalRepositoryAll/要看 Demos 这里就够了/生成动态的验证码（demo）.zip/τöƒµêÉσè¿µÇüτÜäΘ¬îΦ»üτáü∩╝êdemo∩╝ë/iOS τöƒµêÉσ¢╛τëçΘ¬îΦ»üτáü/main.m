//
//  main.m
//  iOS 生成图片验证码
//
//  Created by qsy on 16/3/18.
//  Copyright © 2016年 qsy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
