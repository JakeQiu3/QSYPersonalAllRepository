//
//  AppDelegate.h
//  类似微信发朋友圈图片
//
//  Created by CuiJianZhou on 16/1/28.
//  Copyright © 2016年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

