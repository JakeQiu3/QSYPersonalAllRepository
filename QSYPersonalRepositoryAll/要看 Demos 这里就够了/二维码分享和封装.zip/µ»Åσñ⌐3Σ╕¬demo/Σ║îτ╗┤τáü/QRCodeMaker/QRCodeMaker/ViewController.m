//
//  ViewController.m
//  QRCodeMaker
//
//  Created by 王博 on 15/11/11.
//  Copyright © 2015年 wangbo. All rights reserved.
//

#import "ViewController.h"
#import "NSString+QRCodeImage.h"

@interface ViewController () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextField *textField;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.textField.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    self.imageView.image = [textField.text imageOfQRCodeWithSize:self.imageView.bounds.size.width];
    [textField resignFirstResponder];
    return YES;
}

@end
