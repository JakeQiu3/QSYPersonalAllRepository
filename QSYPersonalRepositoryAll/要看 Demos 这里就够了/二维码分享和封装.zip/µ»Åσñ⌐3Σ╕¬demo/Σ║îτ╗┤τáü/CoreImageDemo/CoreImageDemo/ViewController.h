//
//  ViewController.h
//  CoreImageDemo
//
//  Created by 王博 on 15/7/30.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

