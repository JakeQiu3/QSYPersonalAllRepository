//
//  ViewController.m
//  CoreImageDemo
//
//  Created by 王博 on 15/7/30.
//  Copyright (c) 2015年 wangbo. All rights reserved.
//

#import "ViewController.h"
#import <CoreImage/CoreImage.h>
#import <MobileCoreServices/MobileCoreServices.h>

@implementation CIFilter (UndefinedKey)

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    NSLog(@"CIFilter UndefinedKey: %@", key);
}

@end

@interface ViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDataSource, UITableViewDelegate>
{
    UIImage * _mainImage;
    UIImage * _smallCopyImage;
    CIImage * _workCopyCIImage;
    NSArray * _filterCategories;
    NSMutableDictionary * _filterNamesDict;
    CIContext * _ciContext;
}

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UIImageView *mainImageView;
@property (weak, nonatomic) IBOutlet UIView *faceCoverView;
- (IBAction)pickImageAction:(id)sender;
- (IBAction)faceDetectAction:(id)sender;
- (IBAction)codeDetectAction:(id)sender;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _filterCategories = @[//kCICategoryDistortionEffect,
                          //kCICategoryGeometryAdjustment,
                          //kCICategoryCompositeOperation,
                          //kCICategoryHalftoneEffect,
                          //kCICategoryColorAdjustment,
                          //kCICategoryColorEffect,
                          //kCICategoryTransition,
                          //kCICategoryTileEffect,
                          //kCICategoryGenerator,
                          //kCICategoryReduction,
                          //kCICategoryGradient,
                          //kCICategoryStylize,
                          //kCICategorySharpen,
                          //kCICategoryBlur,
                          kCICategoryVideo,
                          //kCICategoryStillImage,
                          //kCICategoryInterlaced,
                          //kCICategoryNonSquarePixels,
                          //kCICategoryHighDynamicRange,
                          //kCICategoryBuiltIn
                          ];
    
    _filterNamesDict = [NSMutableDictionary dictionaryWithCapacity:_filterCategories.count];
    
    for (NSString * category in _filterCategories) {
        NSArray * arr = [CIFilter filterNamesInCategory:category];
        [_filterNamesDict setObject:arr forKey:category];
        NSLog(@"%@", _filterNamesDict);
    }
    
    _mainImage = self.mainImageView.image;
}

- (void)viewDidAppear:(BOOL)animated {
    _smallCopyImage = [self imageScaledFrom:_mainImage toSize:self.mainImageView.bounds.size];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pickImageAction:(id)sender {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        //UIImagePickerController 系统封装好的加载相机、相册库资源的类
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        //加载不同的资源
        picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
        //是否允许picker对图片资源进行优化
        picker.allowsEditing = YES;
        picker.delegate = self;
        //软件中习惯通过present的方式，呈现相册库
        [self presentViewController:picker animated:YES completion:^{
        }];
    }
}

- (IBAction)faceDetectAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self markFaces:self.mainImageView.image];
    });
}

- (IBAction)codeDetectAction:(id)sender {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self makeCodes:self.mainImageView.image];
    });
}

- (UIImage *)imageWithFilterName:(NSString *)name {
    if (!_workCopyCIImage) {
        _workCopyCIImage = [CIImage imageWithCGImage:_smallCopyImage.CGImage];
    }
    CIFilter* filter = [CIFilter filterWithName:name keysAndValues:@"inputImage", _workCopyCIImage, nil];
    EAGLRenderingAPI api = kEAGLRenderingAPIOpenGLES2; //默认使用2.0版Api
    if (!_ciContext) {
        _ciContext = [CIContext contextWithEAGLContext:[[EAGLContext alloc] initWithAPI:api]];
    }
    CGImageRef cgiImage = [_ciContext createCGImage:filter.outputImage fromRect:_workCopyCIImage.extent];
    return [UIImage imageWithCGImage:cgiImage];
}

#pragma mark - UIImagePickerControllerDelegate
//点击cancel按钮，调用此方法
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    NSLog(@"cancel!");
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
}
//点击choose按钮的时候，触发此方法
//info 带有选中资源的信息
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    //获取资源的类型(图片or视频)
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    //kUTTypeImage 代表图片资源类型
    if ([mediaType isEqualToString:(NSString *)kUTTypeImage]) {
        //直接拿到选中的图片,
        _mainImage = [info objectForKey:UIImagePickerControllerEditedImage];
        if (_mainImage) {
            _smallCopyImage = [self imageScaledFrom:_mainImage toSize:self.mainImageView.bounds.size];
            self.mainImageView.image = _smallCopyImage;
            _workCopyCIImage = nil;
        }
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (UIImage *)imageScaledFrom:(UIImage *)sourceImage toSize:(CGSize)size{
    CGSize newSize;
    if (sourceImage.size.width >= sourceImage.size.height) {
        newSize = CGSizeMake(size.width, sourceImage.size.height * size.width / sourceImage.size.width);
    } else {
        newSize = CGSizeMake(size.height * sourceImage.size.width / sourceImage.size.height, size.height);
    }
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(newSize);
    // 绘制改变大小的图片
    [sourceImage drawInRect:CGRectMake(0,0, newSize.width, newSize.height)];
    // 从当前context中创建一个改变大小后的图片
    UIImage* scaledImage =UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    //返回新的改变大小后的图片
    return scaledImage;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _filterCategories.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString * category = _filterCategories[section];
    return [_filterNamesDict[category] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return _filterCategories[section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    NSString * category = _filterCategories[indexPath.section];
    cell.textLabel.text = _filterNamesDict[category][indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_mainImage) {
        NSString * category = _filterCategories[indexPath.section];
        NSString * filterName = _filterNamesDict[category][indexPath.row];
        [self.activityIndicator startAnimating];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            UIImage * filterImage = [self imageWithFilterName:filterName];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.mainImageView.image = filterImage;
                [self.activityIndicator stopAnimating];
                NSLog(@"%@", NSStringFromCGSize(filterImage.size));
            });
        });
    } else {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

-(void)markFaces:(UIImage *)originalImage
{
    for (UIView * view in [self.faceCoverView subviews]) {
        [view removeFromSuperview];
    }
    // draw a CI image with the previously loaded face detection picture
    CIImage* image = [CIImage imageWithCGImage:originalImage.CGImage];
    
    // create a face detector - since speed is not an issue we'll use a high accuracy
    // detector
    CIDetector* detector = [CIDetector detectorOfType:CIDetectorTypeFace
                                              context:nil options:[NSDictionary dictionaryWithObject:CIDetectorAccuracyHigh forKey:CIDetectorAccuracy]];
    
    // create an array containing all the detected faces from the detector
    NSArray* features = [detector featuresInImage:image];
    
    // we'll iterate through every detected face.  CIFaceFeature provides us
    // with the width for the entire face, and the coordinates of each eye
    // and the mouth if detected.  Also provided are BOOL's for the eye's and
    // mouth so we can check if they already exist.
    for(CIFaceFeature* faceFeature in features)
    {
        // get the width of the face
        CGFloat faceWidth = faceFeature.bounds.size.width;
        
        // create a UIView using the bounds of the face
        UIView* faceView = [[UIView alloc] initWithFrame:faceFeature.bounds];
        
        // add a border around the newly created UIView
        faceView.layer.borderWidth = 1;
        faceView.layer.borderColor = [[UIColor redColor] CGColor];
        
        // add the new view to create a box around the face
        [self.faceCoverView addSubview:faceView];
        
        if(faceFeature.hasLeftEyePosition)
        {
            // create a UIView with a size based on the width of the face
            UIView* leftEyeView = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.leftEyePosition.x-faceWidth*0.15, faceFeature.leftEyePosition.y-faceWidth*0.15, faceWidth*0.3, faceWidth*0.3)];
            // change the background color of the eye view
            [leftEyeView setBackgroundColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]];
            // set the position of the leftEyeView based on the face
            [leftEyeView setCenter:faceFeature.leftEyePosition];
            // round the corners
            leftEyeView.layer.cornerRadius = faceWidth*0.15;
            // add the view to the window
            [self.faceCoverView addSubview:leftEyeView];
        }
        
        if(faceFeature.hasRightEyePosition)
        {
            // create a UIView with a size based on the width of the face
            UIView* rightEyeView = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.rightEyePosition.x-faceWidth*0.15, faceFeature.rightEyePosition.y-faceWidth*0.15, faceWidth*0.3, faceWidth*0.3)];
            // change the background color of the eye view
            [rightEyeView setBackgroundColor:[[UIColor blueColor] colorWithAlphaComponent:0.3]];
            // set the position of the rightEyeView based on the face
            [rightEyeView setCenter:faceFeature.rightEyePosition];
            // round the corners
            rightEyeView.layer.cornerRadius = faceWidth*0.15;
            // add the new view to the window
            [self.faceCoverView addSubview:rightEyeView];
        }
        
        if(faceFeature.hasMouthPosition)
        {
            // create a UIView with a size based on the width of the face
            UIView* mouth = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.mouthPosition.x-faceWidth*0.2, faceFeature.mouthPosition.y-faceWidth*0.2, faceWidth*0.4, faceWidth*0.4)];
            // change the background color for the mouth to green
            [mouth setBackgroundColor:[[UIColor greenColor] colorWithAlphaComponent:0.3]];
            // set the position of the mouthView based on the face
            [mouth setCenter:faceFeature.mouthPosition];
            // round the corners
            mouth.layer.cornerRadius = faceWidth*0.2;
            // add the new view to the window
            [self.faceCoverView addSubview:mouth];
        }
    }
    // 修正坐标
    [self.faceCoverView setTransform:CGAffineTransformMakeScale(1, -1)];
    CGFloat offset = (self.faceCoverView.bounds.size.height - self.mainImageView.image.size.height) / 2;
    [self.faceCoverView setTransform:CGAffineTransformTranslate(self.faceCoverView.transform, 0, offset)];
}

- (void)makeCodes:(UIImage *)originalImage {
    [self.faceCoverView setTransform:CGAffineTransformMakeScale(1, 1)];
    for (UIView * view in [self.faceCoverView subviews]) {
        [view removeFromSuperview];
    }
    CIImage* image = [CIImage imageWithCGImage:originalImage.CGImage];
    // detector
    CIDetector* detector = [CIDetector detectorOfType:CIDetectorTypeQRCode
                                              context:nil
                                              options:@{CIDetectorAccuracy:CIDetectorAccuracyHigh}
                            ];
    if (!detector) {
        NSLog(@"检测器初始化失败");
        return;
    }
    NSArray* features = [detector featuresInImage:image];
    NSString * message = @"";
    for (CIQRCodeFeature * feature in features) {
        message = [message stringByAppendingString:feature.messageString];
    }
    NSLog(@"%@", message);
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.faceCoverView.bounds.size.width, 50)];
    label.numberOfLines = 0;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.5;
    label.text = [NSString stringWithFormat:@"二维码内容：%@", message];
    [self.faceCoverView addSubview:label];
}

@end
