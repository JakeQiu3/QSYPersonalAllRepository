//
//  UIView+Frame.h
//  
//
//  Created by qm on 13/9/22.
//  Copyright (c) 2013年 . All rights reserved.
//

#import <UIKit/UIKit.h>

//分类不能添加成员属性

//@property如果在分类里面，只会自动生成get和set方法的声明，不会生成成员属性和方法的实现


@interface UIView (Frame)

@property (nonatomic,assign) CGFloat x;

@property (nonatomic,assign) CGFloat y;

@property (nonatomic,assign) CGFloat width;

@property (nonatomic,assign) CGFloat height;

@end
