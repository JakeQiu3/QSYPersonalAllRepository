
//
//  TestViewController.m
//  自定义导航控制器
//
//  Created by HelloYeah on 16/3/12.
//  Copyright © 2016年 HelloYeah. All rights reserved.
//

/*
 https://mp.weixin.qq.com/s?__biz=MzAxMzE2Mjc2Ng==&mid=2652154736&idx=1&sn=1545343bddbb061eb5d95241cb4447e2&scene=1&srcid=05208KwCeXv4V92hZNoSxOt6&key=f5c31ae61525f82e7205d3c3dc9f65b07c38dc3ca530286fbe2181fac9d6519d08a5f80f9074a51e1fac120c27c16fb2&ascene=0&uin=MTIyMDA3MjYxOA%3D%3D&devicetype=iMac+MacBookAir4%2C1+OSX+OSX+10.11.5+build(15F34)&version=11020201&pass_ticket=vcPRZT8IsA%2Fh2ZUvUbl9lrKTExi9m%2FKw4xslkn%2FjHabynr5wccpMKI2a6nng1j06
 */
#import "TestViewController.h"
#import "UIViewController+NavBarHidden.h"

@implementation TestViewController

- (void)viewDidLoad{
    
    [super viewDidLoad];
    
    //设置当有导航栏自动添加64的高度的属性为NO
    self.automaticallyAdjustsScrollViewInsets = NO;
    
   
    [self setKeyScrollView:self.tableView scrolOffsetY:600 options:HYHidenControlOptionLeft | HYHidenControlOptionTitle];
    
    //设置tableView的头部视图
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 0, 250)];
    imageView.image = [UIImage imageNamed:@"lol"];
    self.tableView.tableHeaderView = imageView;

}


@end
