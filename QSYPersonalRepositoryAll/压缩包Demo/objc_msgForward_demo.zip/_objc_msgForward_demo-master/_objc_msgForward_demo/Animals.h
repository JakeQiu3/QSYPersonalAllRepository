//
//  Animals.h
//  _objc_msgForward_demo
//
//  Created by luguobin on 15/9/21.
//  Copyright © 2015年 XS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Animals : NSObject
//方法0 1
//- (void)start:(NSString *)str;

@end
