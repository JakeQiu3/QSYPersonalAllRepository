//
//  HMViewController.m
//  07-MapKit05-画线
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//如果想做导航 需要有强大的数据支持
//1.通过应用打开内部应用
//2.在内部集成百度地图

#import "HMViewController.h"
#import <MapKit/MapKit.h>
#import "HMAnnotation.h"

@interface HMViewController () <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic, strong) CLGeocoder *geocoder;
- (IBAction)startNavigation;

@property (nonatomic, strong) MKPlacemark *sourceMKPm;
@property (nonatomic, strong) MKPlacemark *destinationMKPm;
@end

@implementation HMViewController

- (CLGeocoder *)geocoder
{
    if (!_geocoder) {
        self.geocoder = [[CLGeocoder alloc] init];
    }
    return _geocoder;
}

- (IBAction)startNavigation {
    if (self.sourceMKPm == nil || self.destinationMKPm == nil) return;
    
    // 起点
    MKMapItem *sourceItem = [[MKMapItem alloc] initWithPlacemark:self.sourceMKPm];
    
    // 终点
    MKMapItem *destinationItem = [[MKMapItem alloc] initWithPlacemark:self.destinationMKPm];
    
    // 存放起点和终点
    NSArray *items = @[sourceItem, destinationItem];
    
    // 参数
    NSMutableDictionary *options = [NSMutableDictionary dictionary];
    // 导航模式：驾驶导航
    options[MKLaunchOptionsDirectionsModeKey] = MKLaunchOptionsDirectionsModeDriving;
    // 是否要显示路况
    options[MKLaunchOptionsShowsTrafficKey] = @YES;
    
    // 打开苹果官方的导航应用
    [MKMapItem openMapsWithItems:items launchOptions:options];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mapView.delegate = self;
    
    NSString *sourceAddress = @"广州";
    NSString *destinationAddress = @"帝都";
    
    [self.geocoder geocodeAddressString:sourceAddress completionHandler:^(NSArray *placemarks, NSError *error) {
        CLPlacemark *gzPm = [placemarks firstObject];
        if (gzPm == nil) return;
        
        // 添加广州大头针
        HMAnnotation *gzAnno = [[HMAnnotation alloc] init];
        gzAnno.coordinate = gzPm.location.coordinate;
        gzAnno.title = sourceAddress;
        gzAnno.subtitle = gzPm.name;
        [self.mapView addAnnotation:gzAnno];
        
        [self.geocoder geocodeAddressString:destinationAddress completionHandler:^(NSArray *placemarks, NSError *error) {
            CLPlacemark *bjPm = [placemarks firstObject];
            if (bjPm == nil) return;
            
            // 添加北京大头针
            HMAnnotation *bjAnno = [[HMAnnotation alloc] init];
            bjAnno.coordinate = bjPm.location.coordinate;
            bjAnno.title = destinationAddress;
            bjAnno.subtitle = bjPm.name;
            [self.mapView addAnnotation:bjAnno];
            
            [self drawLineWithSourceCLPm:gzPm destinationCLPm:bjPm];
        }];
    }];
}

- (void)drawLineWithSourceCLPm:(CLPlacemark *)sourceCLPm destinationCLPm:(CLPlacemark *)destinationCLPm
{
    if (sourceCLPm == nil || destinationCLPm == nil) return;
    
    // 1.初始化方向请求
    // 方向请求
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    
    // 设置起点
    MKPlacemark *sourceMKPm = [[MKPlacemark alloc] initWithPlacemark:sourceCLPm];
    request.source = [[MKMapItem alloc] initWithPlacemark:sourceMKPm];
    self.sourceMKPm = sourceMKPm;
    
    // 设置终点
    MKPlacemark *destinationMKPm = [[MKPlacemark alloc] initWithPlacemark:destinationCLPm];
    request.destination = [[MKMapItem alloc] initWithPlacemark:destinationMKPm];
    self.destinationMKPm = destinationMKPm;
    
    // 2.根据请求创建方向
    MKDirections *directions = [[MKDirections alloc] initWithRequest:request];
    
    // 3.执行请求
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        if (error) return;
        
        for (MKRoute *route in response.routes) {
            // 添加路线遮盖（传递路线的遮盖模型数据）
            [self.mapView addOverlay:route.polyline];
        }
    }];
    
    // 遮盖 overlay
}

#pragma mark - 代理方法
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay
{
    MKPolylineRenderer *redender = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
    redender.lineWidth = 5;
    redender.strokeColor = [UIColor blueColor];
    return redender;
}

@end
