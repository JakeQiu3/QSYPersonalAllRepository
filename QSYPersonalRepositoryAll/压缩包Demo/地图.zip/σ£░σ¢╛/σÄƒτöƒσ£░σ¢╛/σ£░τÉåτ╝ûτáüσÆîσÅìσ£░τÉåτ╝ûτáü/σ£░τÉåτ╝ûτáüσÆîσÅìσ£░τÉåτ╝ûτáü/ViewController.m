//
//  ViewController.m
//  地理编码和反地理编码
//
//  Created by qianfeng on 15/11/4.
//  Copyright (c) 2015年 樊 运育. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()

@property(nonatomic,strong)CLGeocoder *geocoder ;


#pragma mark - 地理编码
- (IBAction)geocode;
@property (weak, nonatomic) IBOutlet UITextField *addressField;
@property (weak, nonatomic) IBOutlet UILabel *longitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *latitudeLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailAddressLabel;

#pragma mark - 反地理编码
- (IBAction)reverseGeocode;
@property (weak, nonatomic) IBOutlet UITextField *longtitudeField;
@property (weak, nonatomic) IBOutlet UITextField *latitudeField;
@property (weak, nonatomic) IBOutlet UILabel *reverseDetailAddressLabel;

@end

@implementation ViewController

-   (CLGeocoder *)geocoder{
    if (!_geocoder) {
        self.geocoder = [ [CLGeocoder alloc] init];
    }
    return _geocoder;
}

- (void)viewDidLoad {
    [super viewDidLoad];

}

//地理编码     地名 -->  经纬度
-   (void)geocode{
    //1、获得输入的地址
    NSString *address = self.addressField.text;
    if (address.length == 0)         return;
    
    //2、开始编码
    [self.geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error || placemarks.count == 0) {
            self.detailAddressLabel.text = @"你输入的地址找不到！";
        }else {
            //说明编码成功 （找到了具体的位置）
            /*
            for (CLPlacemark *placemark in placemarks){
                //CLPlacemark  地标  封装着详细的地址位置信息：  地理位置  location     区域region        详细的地址信息addressDictionary    地址名称 name       城市  locality
            }
        */
            
            // 显示最前面的地标信息
            CLPlacemark *firstPlacemark = [placemarks firstObject];
            self.detailAddressLabel.text = firstPlacemark.name;
            
            CLLocationDegrees latitude = firstPlacemark.location.coordinate.latitude;
            CLLocationDegrees longitude = firstPlacemark.location.coordinate.longitude;
            self.latitudeLabel.text = [NSString stringWithFormat:@"%.2f", latitude];
            self.longitudeLabel.text = [NSString stringWithFormat:@"%.2f", longitude];
        }
    }];
    
}

//反地理编码   经纬度 --> 地名
-   (void)reverseGeocode{
    NSString *longtitudeText = self.longtitudeField.text;
    NSString *latitudeText = self.latitudeField.text;
    if (longtitudeText.length == 0 || latitudeText.length == 0) return;
    
    CLLocationDegrees latitude = [latitudeText doubleValue];
    CLLocationDegrees longtitude = [longtitudeText doubleValue];
    
    // 开始反向编码
    CLLocation *location = [[CLLocation alloc] initWithLatitude:latitude longitude:longtitude];
    [self.geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error || placemarks.count == 0) {
            self.reverseDetailAddressLabel.text = @"你输入的经纬度找不到，可能在火星上";
        } else { // 编码成功（找到了具体的位置信息）
            // 输出查询到的所有地标信息
            for (CLPlacemark *placemark in placemarks) {
                NSLog(@"name=%@ locality=%@ country=%@ postalCode=%@", placemark.name, placemark.locality, placemark.country, placemark.postalCode);
            }
            
            // 显示最前面的地标信息
            CLPlacemark *firstPlacemark = [placemarks firstObject];
            self.reverseDetailAddressLabel.text = firstPlacemark.name;
            
            CLLocationDegrees latitude = firstPlacemark.location.coordinate.latitude;
            CLLocationDegrees longitude = firstPlacemark.location.coordinate.longitude;
            self.latitudeField.text = [NSString stringWithFormat:@"%.2f", latitude];
            self.longtitudeField.text = [NSString stringWithFormat:@"%.2f", longitude];
        }
    }];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

@end
