//
//  HMAppDelegate.h
//  05-MapKit03-添加大头针
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
