//
//  HMViewController.m
//  05-MapKit03-添加大头针
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMViewController.h"
#import <MapKit/MapKit.h>
#import "HMAnnotation.h"

@interface HMViewController () <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@end

@implementation HMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    HMAnnotation *anno1 = [[HMAnnotation alloc] init];
//    anno1.coordinate = CLLocationCoordinate2DMake(39, 119);
//    anno1.title = @"帝都";
//    anno1.subtitle = @"帝都帝都帝都帝都帝都";
//    // 添加一个大头针模型（模型：描述大头针的信息）
//    [self.mapView addAnnotation:anno1];
//    
//    HMAnnotation *anno2 = [[HMAnnotation alloc] init];
//    anno2.coordinate = CLLocationCoordinate2DMake(23, 116);
//    anno2.title = @"广东";
//    anno2.subtitle = @"广东广东广东广东广东";
//    [self.mapView addAnnotation:anno2];
    
    /**
     纬度范围：N 3°51′ ~  N 53°33′
     经度范围：E 73°33′ ~  E 135°05′
     */
    
    for (int i = 0; i<100; i++) {
        CLLocationDegrees latitude = 23 + arc4random_uniform(20);
        CLLocationDegrees longitude = 73.2 + arc4random_uniform(50);
        
        HMAnnotation *anno = [[HMAnnotation alloc] init];
        anno.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        [self.mapView addAnnotation:anno];
    }
}

@end
