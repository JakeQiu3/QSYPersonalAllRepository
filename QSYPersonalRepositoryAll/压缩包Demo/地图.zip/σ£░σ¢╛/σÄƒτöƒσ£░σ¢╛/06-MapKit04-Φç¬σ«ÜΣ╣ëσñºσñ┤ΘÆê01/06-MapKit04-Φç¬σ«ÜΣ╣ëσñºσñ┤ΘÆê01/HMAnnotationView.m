//
//  HMAnnotationView.m
//  06-MapKit04-自定义大头针01
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMAnnotationView.h"
#import "HMAnnotation.h"

@interface HMAnnotationView()
@property (nonatomic, weak) UIImageView *iconView;
@end

@implementation HMAnnotationView

+ (instancetype)annotationViewWithMapView:(MKMapView *)mapView
{
    static NSString *ID = @"anno";
    HMAnnotationView *annotationView = (HMAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:ID];
    if (annotationView == nil) {
        // 传入循环利用标识来创建大头针控件
        annotationView = [[HMAnnotationView alloc] initWithAnnotation:nil reuseIdentifier:ID];
    }
    return annotationView;
}

- (id)initWithAnnotation:(id<MKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier]) {
        // 显示标题和子标题
        self.canShowCallout = YES;
        
        // 左边显示一个图片
        UIImageView *iconView = [[UIImageView alloc] init];
        iconView.bounds = CGRectMake(0, 0, 50, 50);
        self.leftCalloutAccessoryView = iconView;
        self.iconView = iconView;
    }
    return self;
}

- (void)setAnnotation:(HMAnnotation *)annotation
{
    [super setAnnotation:annotation];
    
    self.image = [UIImage imageNamed:annotation.icon];
    self.iconView.image = self.image;
}

@end
