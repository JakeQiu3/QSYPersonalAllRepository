//
//  HMViewController.m
//  06-MapKit04-自定义大头针01
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMViewController.h"
#import <MapKit/MapKit.h>
#import "HMAnnotation.h"
#import "HMAnnotationView.h"

@interface HMViewController () <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
- (IBAction)add;

@end

@implementation HMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapView.delegate = self;
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
}

- (IBAction)add {
//    HMAnnotation *anno1 = [[HMAnnotation alloc] init];
//    anno1.coordinate = CLLocationCoordinate2DMake(39, 119);
//    anno1.title = @"帝都";
//    anno1.subtitle = @"帝都帝都帝都帝都帝都";
//    anno1.icon = @"me";
//    [self.mapView addAnnotation:anno1];
//    
//    HMAnnotation *anno2 = [[HMAnnotation alloc] init];
//    anno2.coordinate = CLLocationCoordinate2DMake(23, 116);
//    anno2.title = @"广东";
//    anno2.subtitle = @"广东广东广东广东广东";
//    anno2.icon = @"other";
//    [self.mapView addAnnotation:anno2];
    HMAnnotation *tg1 = [[HMAnnotation alloc] init];
    tg1.title = @"xxx大饭店";
    tg1.subtitle = @"全场一律15折，会员20折";
    tg1.icon = @"category_1";
    tg1.coordinate = CLLocationCoordinate2DMake(37, 116);
    [self.mapView addAnnotation:tg1];
    
    HMAnnotation *tg2 = [[HMAnnotation alloc] init];
    tg2.title = @"xxx影院";
    tg2.subtitle = @"最新大片：美国队长2，即将上映。。。";
    tg2.icon = @"category_5";
    tg2.coordinate = CLLocationCoordinate2DMake(29, 110);
    [self.mapView addAnnotation:tg2];
}

#pragma mark - MKMapViewDelegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(HMAnnotation *)annotation
{
    // 返回nil就会按照系统的默认做法
    if (![annotation isKindOfClass:[HMAnnotation class]]) return nil;
    
    // 1.获得大头针控件
    HMAnnotationView *annoView = [HMAnnotationView annotationViewWithMapView:mapView];
    
    // 2.传递模型
    annoView.annotation = annotation;
    
    return annoView;
}

//- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
//{
//   // 1.先从缓存池中取出可以循环利用的大头针控件
//    static NSString *ID = @"anno";
//    MKPinAnnotationView *annotationView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:ID];
//    
//    // 2.缓存池中没有可以循环利用的大头针控件
//    if (annotationView == nil) {
//        // 传入循环利用标识来创建大头针控件
//        annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:nil reuseIdentifier:ID];
//        // 设置头的颜色
//        annotationView.pinColor = MKPinAnnotationColorPurple;
//        // 从天而降
//        annotationView.animatesDrop = YES;
//        // 显示标题和子标题
//        annotationView.canShowCallout = YES;
////        annotationView.calloutOffset = CGPointMake(0, -10);
////        annotationView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeContactAdd];
////        annotationView.leftCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeInfoDark];
//        
//        // 往大头针里面添加一个按钮（测试）
////        [annotationView addSubview:[UIButton buttonWithType:UIButtonTypeContactAdd]];
//    }
//    
//    // 3.传递模型(更新大头针数据，覆盖掉之前的旧数据)
//    annotationView.annotation = annotation;
//    
//    return annotationView;
//}

//- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(HMAnnotation *)annotation
//{
//    // 1.先从缓存池中取出可以循环利用的大头针控件
//    static NSString *ID = @"anno";
//    MKAnnotationView *annotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:ID];
//    
//    // 2.缓存池中没有可以循环利用的大头针控件
//    if (annotationView == nil) {
//        // 传入循环利用标识来创建大头针控件
//        annotationView = [[MKAnnotationView alloc] initWithAnnotation:nil reuseIdentifier:ID];
//        // 显示标题和子标题
//        annotationView.canShowCallout = YES;
//    }
//    
//    // 3.传递模型(更新大头针数据，覆盖掉之前的旧数据)
//    annotationView.annotation = annotation;
//    
//    // 4.设置图片
//    annotationView.image = [UIImage imageNamed:annotation.icon];
//    
//    return annotationView;
//}
@end
