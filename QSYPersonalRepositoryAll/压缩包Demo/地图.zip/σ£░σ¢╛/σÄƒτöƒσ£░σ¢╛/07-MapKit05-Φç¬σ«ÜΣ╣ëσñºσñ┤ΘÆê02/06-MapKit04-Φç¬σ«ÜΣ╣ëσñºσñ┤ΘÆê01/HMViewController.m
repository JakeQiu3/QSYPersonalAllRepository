//
//  HMViewController.m
//  06-MapKit04-自定义大头针01
//
//  Created by apple on 14-8-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMViewController.h"
#import <MapKit/MapKit.h>
#import "HMAnnotation.h"
#import "HMAnnotationView.h"

@interface HMViewController () <MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
- (IBAction)add;

@end

@implementation HMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mapView.delegate = self;
    
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
}

- (IBAction)add {
    HMAnnotation *tg1 = [[HMAnnotation alloc] init];
    tg1.title = @"xxx大饭店";
    tg1.subtitle = @"全场一律15折，会员20折";
    tg1.icon = @"category_1";
    tg1.coordinate = CLLocationCoordinate2DMake(37, 116);
    [self.mapView addAnnotation:tg1];
    
    HMAnnotation *tg2 = [[HMAnnotation alloc] init];
    tg2.title = @"xxx影院";
    tg2.subtitle = @"最新大片：美国队长2，即将上映。。。";
    tg2.icon = @"category_5";
    tg2.coordinate = CLLocationCoordinate2DMake(29, 110);
    [self.mapView addAnnotation:tg2];
}

#pragma mark - MKMapViewDelegate
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(HMAnnotation *)annotation
{
    // 返回nil就会按照系统的默认做法
    if (![annotation isKindOfClass:[HMAnnotation class]]) return nil;
    
    // 1.获得大头针控件
    HMAnnotationView *annoView = [HMAnnotationView annotationViewWithMapView:mapView];
    
    // 2.传递模型
    annoView.annotation = annotation;
    
    return annoView;
}
@end
