# XFBlogDemo

This repository is all my blog Demo.  

<a href="http://weibo.com/xuyafei86">
<img src="http://o74he8slr.bkt.clouddn.com/follow_sina.png", width=32px></a>
<a href="http://www.jianshu.com/users/2555924d8c6e">
<img src="http://o74he8slr.bkt.clouddn.com/follow_jianshu.png", width=32px></a>
<a href="https://github.com/xiaofei86">
<img src="http://o74he8slr.bkt.clouddn.com/follow_blog3.png", width=32px></a>

---

1. XFNavigationController  
[透明与半透明 NavigationBar 切换的三种方案](http://xuyafei.cn/post/cocoatouch/navigationbar)  
2. XFNewsContentDemo  
[使用 WebView + HTML + JavaScript + JSExport 实现图文混排](http://xuyafei.cn/post/cocoatouch/tu-wen-hun-pai)  
[如何准确判断 WebView 加载完成](http://xuyafei.cn/post/cocoatouch/webviewdidfinishload)  