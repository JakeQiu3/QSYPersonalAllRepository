//
//  ViewController.h
//  XFNewsContentDemo
//
/* 实现的功能
 *1、根据model生成的html界面，再用webview加载，实现js和OC交互；
 *2、字体大小调整
 *3、黑夜模式
 */
//  Created by qsy on 16/8/19.
//  Copyright © 2016年 maxthon. All rights reserved.
//

#import "XFNewsListModel.h"

@interface ViewController : UIViewController

@end

