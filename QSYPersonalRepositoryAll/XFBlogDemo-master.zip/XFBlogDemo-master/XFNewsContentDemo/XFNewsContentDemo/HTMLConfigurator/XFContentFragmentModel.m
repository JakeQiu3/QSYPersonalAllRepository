//
//  XFContentFragmentModel.m
//  XFNewsContentDemo
//
//  Created by qsy on 16/8/24.
//  Copyright © 2016年 maxthon. All rights reserved.
//

#import "XFContentFragmentModel.h"

@implementation XFContentFragmentModel

@end
