#import <Foundation/Foundation.h>

NSString * WebViewJavascriptBridge_js();