'use strict';

import { AppRegistry } from 'react-native';
import Main from './src';

AppRegistry.registerComponent('Counters', () => Main);
