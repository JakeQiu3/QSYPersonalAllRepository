# JSPatch Dribbble Demo

![Screenshot](https://raw.github.com/bang590/JSPatch/master/Demo/DribbbleDemo/Screenshot.gif)

A Dribbble iOS client write in JSPatch.

Please install the cocoapods and run `pod install`.