//
//  SwiftDemo-Bridging-Header.h
//  SwiftDemo
//
//  Created by bang on 2/4/16.
//  Copyright © 2016 Arlen. All rights reserved.
//

#ifndef SwiftDemo_Bridging_Header_h
#define SwiftDemo_Bridging_Header_h

#import "JPEngine.h"

#endif /* SwiftDemo_Bridging_Header_h */