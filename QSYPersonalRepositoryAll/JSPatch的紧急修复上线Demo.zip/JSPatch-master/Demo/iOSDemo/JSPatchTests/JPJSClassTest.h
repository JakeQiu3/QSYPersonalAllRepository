//
//  JPJSClassTest.h
//  JSPatchDemo
//
//  Created by bang on 4/1/16.
//  Copyright © 2016 bang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JPJSClassTest : NSObject
+ (BOOL)isPassA;
+ (BOOL)isPassB;
+ (BOOL)isPassC;
@end
