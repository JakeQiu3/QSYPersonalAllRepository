//
//  newProrotcolTest.m
//  JSPatchDemo
//
//  Created by Awhisper on 15/12/27.
//  Copyright © 2015年 bang. All rights reserved.
//

#import "newProtocolTest.h"
#import "JPEngine.h"

#pragma clang diagnostic push

#pragma clang diagnostic ignored "-Wincomplete-implementation"
@implementation baseTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

@implementation structTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

@implementation objectTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

@implementation specialTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

@implementation typeEncodeTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

@implementation classTestProtocolObject
// no method definition
// no crash means addProtocol success
@end

#pragma clang diagnostic pop
