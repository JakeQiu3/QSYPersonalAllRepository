//
//  JPNumberTest.m
//  JSPatchDemo
//
//  Created by pucheng on 16/8/2.
//  Copyright © 2016年 bang. All rights reserved.
//

#import "JPNumberTest.h"

@implementation JPNumberTest

+ (BOOL)testJPNumNSNumber {
    return NO;
}

+ (BOOL)testJPNumNSDecimalNumber {
    return NO;
}

+ (BOOL)testJPNumToJS {
    return NO;
}

+ (BOOL)testJPNUmToOC {
    return NO;
}

@end
