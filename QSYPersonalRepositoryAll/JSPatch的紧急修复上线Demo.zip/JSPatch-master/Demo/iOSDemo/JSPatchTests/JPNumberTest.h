//
//  JPNumberTest.h
//  JSPatchDemo
//
//  Created by pucheng on 16/8/2.
//  Copyright © 2016年 bang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JPNumberTest : NSObject

+ (BOOL)testJPNumNSNumber;
+ (BOOL)testJPNumNSDecimalNumber;
+ (BOOL)testJPNumToJS;
+ (BOOL)testJPNUmToOC;

@end
