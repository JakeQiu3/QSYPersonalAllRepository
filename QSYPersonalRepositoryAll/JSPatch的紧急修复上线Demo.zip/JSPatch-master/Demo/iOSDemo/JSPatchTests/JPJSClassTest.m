//
//  JPJSClassTest.m
//  JSPatchDemo
//
//  Created by bang on 4/1/16.
//  Copyright © 2016 bang. All rights reserved.
//

#import "JPJSClassTest.h"

@implementation JPJSClassTest
+ (BOOL)isPassA
{
    return NO;
}
+ (BOOL)isPassB
{
    return NO;
}
+ (BOOL)isPassC
{
    return NO;
}
@end
