require('UILabel, UIColor, UIFont, UIScreen, UIImageView, UIImage')

var screenWidtha = UIScreen.mainScreen().bounds().width;
var screenHeighta = UIScreen.mainScreen().bounds().height;

