//
//  JPErrorView.h
//  JSPatchPlaygroundDemo
//
//  Created by Awhisper on 16/8/7.
//  Copyright © 2016年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JPDevErrorView : UIView

- (instancetype)initError:(NSString *)errMsg;

@end
