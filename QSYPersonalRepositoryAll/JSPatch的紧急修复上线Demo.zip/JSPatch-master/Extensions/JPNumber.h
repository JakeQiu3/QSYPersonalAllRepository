//
//  JPNumber.h
//  JSPatchDemo
//
//  Created by pucheng on 16/7/5.
//  Copyright © 2016年 pucheng. All rights reserved.
//

#import "JPEngine.h"
@interface JPNumber : JPExtension

@end
