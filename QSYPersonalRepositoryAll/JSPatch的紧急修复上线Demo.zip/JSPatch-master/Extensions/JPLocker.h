//
//  JPLocker.h
//  JSPatchDemo
//
//  Created by bang on 3/22/16.
//  Copyright © 2016 bang. All rights reserved.
//

#import "JPEngine.h"

@interface JPLocker : JPExtension

@end
