#ifdef __arm64__

#include "ffitarget_arm64.h"


#endif
#ifdef __i386__

#include "ffitarget_i386.h"


#endif
#ifdef __arm__

#include "ffitarget_armv7.h"


#endif
#ifdef __x86_64__

#include "ffitarget_x86_64.h"


#endif
