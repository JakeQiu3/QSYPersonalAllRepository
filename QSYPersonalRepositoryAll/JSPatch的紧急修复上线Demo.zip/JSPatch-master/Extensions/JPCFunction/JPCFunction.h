//
//  JPCFunction.h
//  JSPatchDemo
//
//  Created by bang on 5/30/16.
//  Copyright © 2016 bang. All rights reserved.
//

#import "JPEngine.h"

@interface JPCFunction : JPExtension

@end
