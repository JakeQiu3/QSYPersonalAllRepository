//
//  VLHiOptionalViewController.h
//  VoiceLink
//
//  Created by fanyunyu on 16/1/12.
//  Copyright © 2016年 voilink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VLHiOptionalViewController : UIViewController


@property (nonatomic, copy)  NSString *navTitle;

/**
 *  购买的产品编号
 */
@property (nonatomic, copy)  NSString *packageNo;


@property (nonatomic, copy)  NSString *desc;

@end
