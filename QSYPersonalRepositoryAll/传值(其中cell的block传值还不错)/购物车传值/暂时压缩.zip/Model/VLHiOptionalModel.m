//
//  VLHiOptionalModel.m
//  VoiceLink
//
//  Created by fanyunyu on 16/1/13.
//  Copyright © 2016年 voilink. All rights reserved.
//

#import "VLHiOptionalModel.h"

@implementation VLHiOptionalModel





@end
