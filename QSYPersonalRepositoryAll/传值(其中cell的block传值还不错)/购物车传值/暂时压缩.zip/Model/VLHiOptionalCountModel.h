//
//  VLHiOptionalCountModel.h
//  VoiceLink
//
//  Created by fanyunyu on 16/1/14.
//  Copyright © 2016年 voilink. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VLHiOptionalCountModel : NSObject

@property (nonatomic, copy)  NSString *productNo;

@property (nonatomic, copy)  NSString *price;

@property (nonatomic, assign)  NSInteger times;






@end
