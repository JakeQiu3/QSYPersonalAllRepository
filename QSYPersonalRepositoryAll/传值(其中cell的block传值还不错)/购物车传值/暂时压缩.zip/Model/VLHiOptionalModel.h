//
//  VLHiOptionalModel.h
//  VoiceLink
//
//  Created by fanyunyu on 16/1/13.
//  Copyright © 2016年 voilink. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VLHiOptionalModel : NSObject


@property (nonatomic, copy)  NSString *productName;

@property (nonatomic, copy)  NSString *bidPrice;

@property (nonatomic, copy)  NSString *price;

@property (nonatomic, copy)  NSString *times;


@end
