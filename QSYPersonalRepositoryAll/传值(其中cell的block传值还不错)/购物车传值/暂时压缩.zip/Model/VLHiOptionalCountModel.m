//
//  VLHiOptionalCountModel.m
//  VoiceLink
//
//  Created by fanyunyu on 16/1/14.
//  Copyright © 2016年 voilink. All rights reserved.
//

#import "VLHiOptionalCountModel.h"

@implementation VLHiOptionalCountModel

@end
