//
//  QLKWebPageViewController.h
//  Qilekang
//
//  Created by 程显坤 on 13-7-12.
//  Copyright (c) 2013年 Qilekang. All rights reserved.
//

#import "QLKBaseViewController.h"
@class BaseUIWebView;

@interface QLKWebPageViewController : BaseViewController<UIWebViewDelegate, UIActionSheetDelegate>
{
    
}
@property (nonatomic, strong) BaseUIWebView *webView;
@property (nonatomic, strong) NSString *jsAction;
- (id)initWithURLString:(NSString *)URLString;
- (id)initWithURLStringWithoutEncoding:(NSString *)URLString;
- (void)addExecuteJsActionMethod:(NSString *)jsValue;// 新增执行JS时的方法
@end