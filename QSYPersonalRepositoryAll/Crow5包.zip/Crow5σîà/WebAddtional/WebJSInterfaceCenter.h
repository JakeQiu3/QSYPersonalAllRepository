//
//  WebJSInterfaceCenter.h
//  Qilekang
//
//  Created by YULING MINA on 14-8-12.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWLSynthesizeSingleton.h"

/**
 *  WebJSInterfaceCenter 非注入方法库：该类中的方法不是注册要用的，故操作时需要删除掉
 */
@interface LFJSInterfaceProtocol : NSObject<UIAlertViewDelegate>

/**
 *  OC注入JS方法列表
 *
 *  @return 方法列表，STRING
 */
- (NSArray *)registerJSMethodArray;

/**
 *  执行Html中的JS调用后，并把结果作为字符串返回给OC
 *
 *  @param method 方法名
 *  @param params 方法参数
 *
 *  @return 任意类型值均以字符串输出
 */
- (NSString *)invokeJSMethod:(NSString *)method params:(NSDictionary *)params;

@end

/**
 *  方法返回值和参数支持类型：NSString和C基础类型；不支持NSArray和NSDictionary等等
 *  支持类型：void,char,short,int,long,long long,unsigned int,unsigned long,unsigned long long,float,double,NSString
 */
@interface WebJSInterfaceCenter : LFJSInterfaceProtocol
@property (nonatomic,strong)BaseViewController*currController;
@property (nonatomic,strong)NSArray*jsMethodArr;//oc与js方法数组,由JS代码来调用的OC方法名数组
// 实例函数

/**
 *  获取设备信息
 *
 *  @return 设备信息
 */
- (NSString *)getSysInfo;
/**
 *  获取APP信息
 *  @return app信息
 */
- (NSString *)getAppInfo;

/**
 *  获取用户信息
 *
 *  @return 用户信息
 */
-(NSString *)getUserInfo;
/**
 *  设置webtitle
 *
 *  @param title 标题
 */
-(void)setPageTitle:(NSString *)title;
/**
 *  页面跳转
 *
 *  @param key 页面协议
 */
-(void)webToAppPage:(NSString *)key;
///**
// *  获取上一级页面Id
// *
// */
//- (NSString *)getSuperViewId;
/**
 *  提示
 *
 *  @param json 提示信息内容
 */
-(void)appAlert:(NSString *)json;
/**
 *  吐丝
 *
 *  @param mes 内容
 */
- (void)showToast:(NSString *)mes;
/**
 *  退出登录
 */
- (void)appLogOut;

/**
 *  开始动画
 */
- (void)startLoadView;
/**
 *  结束动画
 */
- (void)stopLoadView;
/**
 *  设置右上角按钮
 *  type:1协议类型，2回调类型
 *  @param json {"title":"按钮","type":"1","linkUrl":"url"}
 */
- (void)addRightButt:(NSString *)json;
/**
 *  JS发送BI
 *
 *  @param json 这只有data
 */
-(void)sendBIWithJson:(NSString *)json;
/**
 *  分享
 *
 */
- (void)shareAction:(NSString *)json;

/**
 *  设置app缓存
 *
 *  @param json key value
 */
- (void)setAppCache:(NSString *)json;
/**
 *  获取app缓存
 *
 *  @param key key
 *
 *  @return value
 */
- (NSString *)getAppCache:(NSString *)key;
/**
 *  获取账户余额
 *
 *  @param key
 */
- (NSString *)getPrice;
/**
 *  获取城市列表
 *
 *
 *  @return value
 */
- (NSString *)getCityList;
/**
 *  获取科室信息
 *
 *
 *  @return value
 */
- (NSString *)getDepartments;
/**
 *  删除app缓存
 *
 *  @param key key
 */
- (void)removeAppCache:(NSString *)key;
/**
 *  获取取消预约内容
 *
 */
- (NSString *)getCancelDetailList;
/**
 * 我的医生指导提示信息
 *
 */
- (void )showHtml5Help:(NSString *)json;

/**
 *  页面标识
 *
 *  @param string viewId  页面标识
 */
- (void)setCurrViewId:(NSString *)viewId;
/**
 *  获取定位信息
 *
 */
- (NSString *)getLocationCity;

CWL_DECLARE_SINGLETON_FOR_CLASS(WebJSInterfaceCenter)
@end
