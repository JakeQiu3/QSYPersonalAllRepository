//
//  BaseUIWebView.m
//  Qilekang
//
//  Created by Warren on 5/15/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import "BaseUIWebView.h"
#import <objc/runtime.h>
#import "WebHttpProtocol.h"
#import "OfflineCacheURLProtocol.h"
#import "H5MethodForwarder.h"
#import "Reachability.h"
#import "WebLocalStorageWriter.h"

#define kDefaultWebBGColor [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1]

@implementation UIWebView (clean)
- (void) cleanForDealloc{
    [self loadHTMLString:@"" baseURL:nil];
    [self stopLoading];
    [self removeFromSuperview];
    self.delegate = nil;
}
@end

@implementation BaseUIWebView{
    NSURLRequest*           _requestBak;
}
//初始化self时执行该method
+ (void)initialize{
    [NSURLProtocol registerClass:[WebHttpProtocol class]];
}

//initialize完后，就执行该method
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setOpaque:NO];
        self.backgroundColor = [UIColor whiteColor];
        UIScrollView* scview = [self contentScrollView];
        scview.decelerationRate = UIScrollViewDecelerationRateNormal;
        scview.backgroundColor = kDefaultWebBGColor;
        for (UIView* v in scview.subviews) {
            if ([v isKindOfClass:[UIImageView class]]) {
                v.hidden = YES;
            }
        }
    }
    return self;
}

/**
 *  override
 *
 *  @param backgroundColor UIColor
 */
- (void)setBackgroundColor:(UIColor *)backgroundColor
{
    [super setBackgroundColor:backgroundColor];
    [[self contentScrollView] setBackgroundColor:backgroundColor];
}

/**
 *  获取webview中内容区域，即scrollview
 *
 *  @return UIScrollView
 */
- (UIScrollView *)contentScrollView
{
    if ([self respondsToSelector:@selector(scrollView)]) {
        return [self scrollView];
    }else{
        static UIScrollView *scrollView = nil;
        if (scrollView) {
            return scrollView;
        }
        for (UIView* sub in self.subviews) {
            if ([sub isKindOfClass:[UIScrollView class]]) {
                scrollView = (UIScrollView *)sub;
                break;
            }
        }
        return scrollView;
    }
}
//重写dealloc:执行loadString为空，停止加载，并移除self，同时代理置nil
-(void)dealloc{
    [self cleanForDealloc];
    [self setDelegate:nil];
}
// 重写loadRequest：把加载的request 赋值给self的变量_requestBak
-(void)loadRequest:(NSURLRequest *)request{
    [super loadRequest:request];
    _requestBak = request;
    QLKDLog(@"webview loadRequest:%@", request.URL);
}

#pragma mark UIWebViewDelegate
// 重写shouldStartLoadWithRequest：延时30秒执行关闭吐丝
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    BOOL ret = YES;
    ret = [super webView:webView shouldStartLoadWithRequest:request navigationType:navigationType];
    [self performSelector:@selector(closeToastViewAnimation) withObject:nil afterDelay:30];
    return ret;
}
-(void)closeToastViewAnimation{
    [ToastView hideActivityAnimation];
}
// 重写didFailLoadWithError：关闭吐丝，以及约定若self的变量_requestBak的的url的absoluteString有loading=0时，不启动动画等
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [super webView:webView didFailLoadWithError:error];
    [ToastView hideActivityAnimation];
    // 与H5约定，如果url中包含loading=0，则不启动loading动画
    if (_requestBak && !([_requestBak.URL.absoluteString rangeOfString:@"loading=0"].length > 0)) {
        
    }
    
    if (error.code == NSURLErrorBadServerResponse
        || error.code == NSURLErrorNotConnectedToInternet
        || error.code == NSURLErrorCannotConnectToHost) {
        
    }
}
// 重写webViewDidFinishLoad：关闭吐丝，以及约定若self的变量_requestBak的的url的absoluteString有loading=0时，不启动动画等
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [ToastView hideActivityAnimation];
    [super webViewDidFinishLoad:webView];
    // 与H5约定，如果url中包含loading=0，则不启动loading动画
    if (_requestBak && !([_requestBak.URL.absoluteString rangeOfString:@"loading=0"].length > 0)) {
       
    }
}

@end
