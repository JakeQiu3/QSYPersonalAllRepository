//
//  WebCacheURLMgr.m
//  Qilekang
//
//  Created by YULING MINA on 14-7-25.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//

#import "WebCacheURLMgr.h"

@implementation LFCacheURLData
@synthesize httpRequest, httpResponse, responseData, redirectRequest;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if (self) {
        [self setHttpRequest:[aDecoder decodeObjectForKey:@"httpRequest"]];
        [self setHttpResponse:[aDecoder decodeObjectForKey:@"httpResponse"]];
        [self setResponseData:[aDecoder decodeObjectForKey:@"responseData"]];
        [self setRedirectRequest:[aDecoder decodeObjectForKey:@"redirectRequest"]];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:httpRequest forKey:@"httpRequest"];
    [aCoder encodeObject:httpResponse forKey:@"httpResponse"];
    [aCoder encodeObject:responseData forKey:@"responseData"];
    [aCoder encodeObject:redirectRequest forKey:@"redirectRequest"];
}

- (void)dealloc
{
    [httpRequest release];
    [httpResponse release];
    [responseData release];
    [redirectRequest release];
    [super dealloc];
}

@end

/************************************** WebCacheURLMgr *********************************************/
static NSInteger cacheMaxCacheAge = 60*60*24*7; // 1 week

@interface WebCacheURLMgr()

@property (nonatomic, copy) NSString *diskCachePath;
@property (nonatomic, retain) NSArray *supportMIMETYPE;

/**
 *  磁盘缓存路径
 *
 *  @return
 */
- (NSString *)cacheDiskPath:(NSURLRequest *)request;

/**
 *  清除磁盘缓存
 */
- (void)cleanDisk;

@end

@implementation WebCacheURLMgr
CWL_SYNTHESIZE_SINGLETON_FOR_CLASS(WebCacheURLMgr)

- (id)init
{
    self = [super init];
    if (self) {
        self.supportMIMETYPE = @[@"image/bmp", @"image/gif", @"image/jpeg", @"image/png"];
        NSString *cachesPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        self.diskCachePath = [cachesPath stringByAppendingPathComponent:@"WebViewCache"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:self.diskCachePath])
        {
            [[NSFileManager defaultManager] createDirectoryAtPath:self.diskCachePath
                                      withIntermediateDirectories:YES
                                                       attributes:nil
                                                            error:NULL];
        }
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(cleanDisk)
                                                     name:UIApplicationWillTerminateNotification
                                                   object:nil];
    }
    return self;
}

- (void)dealloc
{
    [_diskCachePath release];
    [_supportMIMETYPE release];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

+ (NSArray *)SupportCacheMIMETYPE
{
    return [[self sharedWebCacheURLMgr] supportMIMETYPE];
}

- (BOOL)isSupportMIMETYPE:(NSString *)MIMETYPE
{
    return NO;
    return [self.supportMIMETYPE indexOfObject:MIMETYPE] != NSNotFound;
}

- (NSString *)cacheDiskPath:(NSURLRequest *)request
{
    return [self.diskCachePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", [[[request URL] absoluteString] MD5EncodingString]]];
}

- (LFCacheURLData *)cacheDataForRequest:(NSURLRequest *)request
{
    return nil;
    return [NSKeyedUnarchiver unarchiveObjectWithFile:[self cacheDiskPath:request]];
}

- (void)removeCacheForRequest:(NSURLRequest *)request
{
    [[NSFileManager defaultManager] removeItemAtPath:[self cacheDiskPath:request] error:nil];
}

- (void)URLRequest:(NSURLRequest *)request URLResponse:(NSURLResponse *)response didReceivedData:(NSData *)data
{
    [self URLRequest:request URLRedirectRequest:nil URLResponse:response didReceivedData:data];
}

- (void)URLRequest:(NSURLRequest *)request URLRedirectRequest:(NSURLRequest *)redirectRequest URLResponse:(NSURLResponse *)response didReceivedData:(NSData *)data
{
    return;
    LFCacheURLData *cache = [LFCacheURLData new];
    [cache setHttpRequest:request];
    [cache setHttpResponse:response];
    [cache setResponseData:data];
    [cache setRedirectRequest:redirectRequest];
    
    NSString *cachePath = [self cacheDiskPath:request];
    [NSKeyedArchiver archiveRootObject:cache toFile:cachePath];
    [cache release];
}

- (void)cleanDisk
{
    NSDate *expirationDate = [NSDate dateWithTimeIntervalSinceNow:-cacheMaxCacheAge];
    NSDirectoryEnumerator *fileEnumerator = [[NSFileManager defaultManager] enumeratorAtPath:self.diskCachePath];
    for (NSString *fileName in fileEnumerator)
    {
        NSString *filePath = [self.diskCachePath stringByAppendingPathComponent:fileName];
        NSDictionary *attrs = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
        if ([[[attrs fileModificationDate] laterDate:expirationDate] isEqualToDate:expirationDate])
        {
            [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        }
    }
}

- (void)clearDisk
{
    [[NSFileManager defaultManager] removeItemAtPath:self.diskCachePath error:nil];
    [[NSFileManager defaultManager] createDirectoryAtPath:self.diskCachePath
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
}

@end
