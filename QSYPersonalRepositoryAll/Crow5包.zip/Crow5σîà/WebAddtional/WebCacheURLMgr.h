//
//  WebCacheURLMgr.h
//  Qilekang
//
//  Created by wj on 14-7-25.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWLSynthesizeSingleton.h"

/**
 *  每次请求缓存数据
 */
@interface LFCacheURLData : NSObject <NSCoding>

@property (nonatomic, retain) NSURLRequest *httpRequest;
@property (nonatomic, retain) NSURLResponse *httpResponse;
@property (nonatomic, retain) NSData *responseData;

@property (nonatomic, retain) NSURLRequest *redirectRequest;

@end

/**
 *  UIWebView 缓存
 */
@interface WebCacheURLMgr : NSObject

/**
 *  支持缓存的mimetype列表
 *
 *  @return
 */
+ (NSArray *)SupportCacheMIMETYPE;

/**
 *  是否支持MIMETYPE
 *
 *  @param MIMETYPE content-type类型
 *
 *  @return
 */
- (BOOL)isSupportMIMETYPE:(NSString *)MIMETYPE;

/**
 *  该网络请求缓存数据
 *
 *  @param request 网络请求
 *
 *  @return 
 */
- (LFCacheURLData *)cacheDataForRequest:(NSURLRequest *)request;

/**
 *  删除缓存
 *
 *  @param request
 */
- (void)removeCacheForRequest:(NSURLRequest *)request;

/**
 *  网络请求结束返回数据
 *
 *  @param request  网络请求
 *  @param response 网络响应
 *  @param data     返回数据
 */
- (void)URLRequest:(NSURLRequest *)request URLResponse:(NSURLResponse *)response didReceivedData:(NSData *)data;

/**
 *  网络请求跳转
 *
 *  @param request         请求
 *  @param redirectRequest 跳转请求
 *  @param response
 *  @param data
 */
- (void)URLRequest:(NSURLRequest *)request URLRedirectRequest:(NSURLRequest *)redirectRequest URLResponse:(NSURLResponse *)response didReceivedData:(NSData *)data;

/**
 *  Clear all disk cached files
 */
- (void)clearDisk;

/**
 *  Remove all expired cached files from disk
 */
- (void)cleanDisk;

CWL_DECLARE_SINGLETON_FOR_CLASS(WebCacheURLMgr)

@end
