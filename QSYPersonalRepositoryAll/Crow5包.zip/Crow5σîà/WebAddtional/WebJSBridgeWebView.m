//
//  WebJSBridgeWebView.m
//  Qilekang
//
//  Created by wj on 14-7-7.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//

#import "WebJSBridgeWebView.h"
#import "WebJSInterfaceCenter.h"

#if __has_feature(objc_arc_weak)
#define WVJB_WEAK __weak
#else
#define WVJB_WEAK __unsafe_unretained
#endif

typedef NSDictionary WVJBMessage;
typedef NSDictionary WVJBMethod;

@implementation WebJSBridgeWebView {
    WVJB_WEAK id _webViewDelegate;
    NSMutableArray* _startupMessageQueue;
    NSMutableArray* _startupMethodQueue;
    NSMutableDictionary* _responseCallbacks;
    NSMutableDictionary* _messageHandlers;
    long _uniqueId;
    WVJBHandler _messageHandler;
    
    NSUInteger _numRequestsLoading;
}
// init mehtod：设置了delegata、reset所有的方法、消息字典和注册了JSMethod
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self _platformSpecificSetup];
        [self reset];
        [self _registerJSMethod];
    }
    return self;
}
// init mehtod：设置了delegata、reset所有的方法、消息字典和注册了JSMethod
- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self _platformSpecificSetup];
        [self reset];
        [self _registerJSMethod];
    }
    return self;
}

- (void)dealloc
{
    [self _platformSpecificDealloc];
    
    _webViewDelegate = nil;
    [_startupMessageQueue release];
    _startupMessageQueue = nil;
    [_startupMethodQueue release];
    _startupMethodQueue = nil;
    [_responseCallbacks release];
    _responseCallbacks = nil;
    [_messageHandlers release];
    _messageHandlers = nil;
    [_messageHandler release];
    _messageHandler = nil;
    [super dealloc];
}

/**
 *  override setDelegate
 *
 *  @param delegate delegate
 */
- (id<UIWebViewDelegate>)delegate
{
    return _webViewDelegate;
}

- (void)setDelegate:(id<UIWebViewDelegate>)delegate
{
    if (![delegate isKindOfClass:[self class]]) {
        _webViewDelegate = delegate;
    }else{
        _webViewDelegate = nil;
    }
    if(delegate){
      [super setDelegate:self];
    }
}

- (void)send:(id)data
{
    [self send:data responseCallback:nil];
}

- (void)send:(id)data responseCallback:(WVJBResponseCallback)responseCallback
{
    [self _sendData:data responseCallback:responseCallback handlerName:nil];
}

- (void)callHandler:(NSString *)handlerName
{
    [self callClass:nil handler:handlerName];
}

- (void)callHandler:(NSString *)handlerName data:(id)data
{
    [self callClass:nil handler:handlerName data:data];
}

- (void)callHandler:(NSString *)handlerName data:(id)data responseCallback:(WVJBResponseCallback)responseCallback
{
    [self callClass:nil handler:handlerName data:data responseCallback:responseCallback];
}

- (void)callClass:(NSString *)className handler:(NSString *)handlerName
{
    [self callClass:className handler:handlerName data:nil responseCallback:nil];
}

- (void)callClass:(NSString *)className handler:(NSString *)handlerName data:(id)data
{
    [self callClass:className handler:handlerName data:data responseCallback:nil];
}

- (void)callClass:(NSString *)className handler:(NSString *)handlerName data:(id)data responseCallback:(WVJBResponseCallback)responseCallback
{
    if (className) {
        [self _sendData:data responseCallback:responseCallback handlerName:[NSString stringWithFormat:@"%@.%@", className, handlerName]];
    }else{
        [self _sendData:data responseCallback:responseCallback handlerName:handlerName];
    }
}

- (void)registerHandler:(NSString *)handlerName handler:(WVJBHandler)handler
{
    _messageHandlers[handlerName] = [[handler copy] autorelease];
}

- (void)registerMethod:(NSString *)methodName handler:(WVJBHandler)handler
{
    [self registerHandler:methodName handler:handler];
    
    NSMutableDictionary* message = [NSMutableDictionary dictionary];
    
    if (methodName) {
        message[@"handlerName"] = methodName;
    }
    
    [self _queueMethod:message];
}

- (void)reset
{
    [_startupMessageQueue release];
    _startupMessageQueue = nil;
    _startupMessageQueue = [[NSMutableArray array] retain];
    [_startupMethodQueue release];
    _startupMethodQueue = nil;
    _startupMethodQueue = [[NSMutableArray array] retain];
    [_responseCallbacks release];
    _responseCallbacks = nil;
    _responseCallbacks = [[NSMutableDictionary dictionary] retain];
    _uniqueId = 0;
}

- (void)setWebJSHandler:(WVJBHandler)handler
{
    [_messageHandler release];
    if (handler) {
        _messageHandler = [handler copy];
    }
}

/**
 *  API
 *
 */
static bool logging = false;
+ (void)enableLogging{ logging = true; }

- (void)_platformSpecificSetup
{
    [self setDelegate:self];
    _messageHandlers = [[NSMutableDictionary dictionary] retain];
}

- (void)_platformSpecificDealloc
{
    [self setDelegate:nil];
    if (self.isLoading) {
        [self dismissLoadingProgress];
    }
}
#pragma mark 注册JS要调用的OC方法
- (void)_registerJSMethod
{
    __block typeof(self) weak_self = self;
    // 仅仅执行1次：获取和OC商定的待注册的JS方法
    NSArray *method_list = [[WebJSInterfaceCenter sharedWebJSInterfaceCenter] registerJSMethodArray];
    for (NSString *method_name in method_list) {
        // 执行注册的方法名：data为JS传递给OC的参数，responseCallback是返回给JS的数据
        [self registerMethod:method_name handler:^(id data, WVJBResponseCallback responseCallback) {
            // 通知其他观察者
            [[NSNotificationCenter defaultCenter] postNotificationName:JS_2_OC_NOTIFY
                                                                object:weak_self
                                                              userInfo:[NSDictionary dictionaryWithObjectsAndKeys:method_name, JS_2_OC_KEY, data, JS_2_OC_PARAM, nil]];
            // 回调处理
            id responseData = [[WebJSInterfaceCenter sharedWebJSInterfaceCenter] invokeJSMethod:method_name params:data];
            if (responseData) {
                responseCallback(responseData);
            }else{
                responseCallback(@"");
            }
        }];
    }
}

- (void)_sendData:(id)data responseCallback:(WVJBResponseCallback)responseCallback handlerName:(NSString*)handlerName {
    NSMutableDictionary* message = [NSMutableDictionary dictionary];
    
    if (data) {
        message[@"data"] = data;
    }
    
    if (responseCallback) {
        NSString* callbackId = [NSString stringWithFormat:@"objc_cb_%ld", ++_uniqueId];
        _responseCallbacks[callbackId] = [responseCallback copy];
        message[@"callbackId"] = callbackId;
    }
    
    if (handlerName) {
        message[@"handlerName"] = handlerName;
    }
    
    [self _queueMessage:message];
}

- (void)_queueMessage:(WVJBMessage*)message {
    if (_startupMessageQueue) {
        [_startupMessageQueue addObject:message];
    } else {
        [self _dispatchMessage:message];
    }
}

- (void)_queueMethod:(WVJBMethod*)method{
    if (_startupMethodQueue) {
        [_startupMethodQueue addObject:method];
    }else{
        [self _dispatchMethod:method];
    }
}

- (void)_dispatchMessage:(WVJBMessage*)message {
    [self _dispatchJS:message jsFormat:@"JSBridge._handleMessageFromObjC('%@');"];
}

- (void)_dispatchMethod:(WVJBMethod*)method{
    [self _dispatchJS:method jsFormat:@"JSBridge.registerMapMethod('%@');"];
}

- (void)_dispatchJS:(NSDictionary *)js jsFormat:(NSString *)jsFormat
{
    NSString *messageJSON = [self _serializeMessage:js];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\'" withString:@"\\\'"];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\n" withString:@"\\n"];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\r" withString:@"\\r"];
    messageJSON = [messageJSON stringByReplacingOccurrencesOfString:@"\f" withString:@"\\f"];
    
    NSString* javascriptCommand = [NSString stringWithFormat:jsFormat, messageJSON];
    if ([[NSThread currentThread] isMainThread]) {
        [self stringByEvaluatingJavaScriptFromString:javascriptCommand];
    } else {
        WVJB_WEAK UIWebView *strongWebView = self;
        dispatch_sync(dispatch_get_main_queue(), ^{
            [strongWebView stringByEvaluatingJavaScriptFromString:javascriptCommand];
        });
    }
}

- (void)_flushMessageQueue {
    NSString *messageQueueString = [self stringByEvaluatingJavaScriptFromString:@"JSBridge._fetchQueue();"];
    
    id messages = [self _deserializeMessageJSON:messageQueueString];
    if (![messages isKindOfClass:[NSArray class]]) {
        QLKDLog(@"JSBridge: WARNING: Invalid %@ received: %@", [messages class], messages);
        return;
    }
    for (WVJBMessage* message in messages) {
        if (![message isKindOfClass:[WVJBMessage class]]) {
            QLKDLog(@"JSBridge: WARNING: Invalid %@ received: %@", [message class], message);
            continue;
        }
        [self _log:@"RCVD" json:message];
        
        NSString* responseId = message[@"responseId"];
        if (responseId) {
            WVJBResponseCallback responseCallback = _responseCallbacks[responseId];
            responseCallback(message[@"responseData"]);
            [_responseCallbacks removeObjectForKey:responseId];
        } else {
            WVJBResponseCallback responseCallback = NULL;
            NSString* callbackId = message[@"callbackId"];
            if (callbackId) {
                responseCallback = ^(id responseData) {
                    WVJBMessage* msg = @{ @"responseId":callbackId, @"responseData":responseData };
                    [self _dispatchMessage:msg];
                };
            } else {
                responseCallback = ^(id ignoreResponseData) {
                    // Do nothing
                };
            }
            
            WVJBHandler handler;
            if (message[@"handlerName"]) {
                handler = _messageHandlers[message[@"handlerName"]];
                if (!handler) {
                    QLKDLog(@"WVJB Warning: No handler for %@", message[@"handlerName"]);
                    return responseCallback(@{});
                }
            } else {
                handler = _messageHandler;
            }
            
            @try {
                NSDictionary *data = [[NSDictionary alloc] initWithDictionary:message[@"data"]];
                handler(data, responseCallback);
            }
            @catch (NSException *exception) {
                QLKDLog(@"JSBridge: WARNING: objc handler threw. %@ %@", message, exception);
            }
        }
    }
}

- (NSString *)_serializeMessage:(id)message
{
    return [[[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:message options:0 error:nil] encoding:NSUTF8StringEncoding] autorelease];
}

- (NSArray*)_deserializeMessageJSON:(NSString *)messageJSON
{
    return [NSJSONSerialization JSONObjectWithData:[messageJSON dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
}

- (void)_log:(NSString *)action json:(id)json
{
    if (!logging) { return; }
    if (![json isKindOfClass:[NSString class]]) {
        json = [self _serializeMessage:json];
    }
    if ([json length] > 500) {
        QLKDLog(@"WVJB %@: %@ [...]", action, [json substringToIndex:500]);
    } else {
        QLKDLog(@"WVJB %@: %@", action, json);
    }
}

#pragma mark- WebView Alert
- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame
{
    NSURL *url = [NSURL URLWithString:message];
    if ([kCustomProtocolScheme isEqualToString:[url scheme]]) {
        if ([kQueueHasMessage isEqualToString:[url host]]) {
            [self _flushMessageQueue];
        } else {
            QLKDLog(@"JSBridge: WARNING: Received unknown JSBridge command %@://%@", kCustomProtocolScheme, [url path]);
        }
     }else if(message && message.length > 0){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}

- (void)showLoadingProgress
{
}

- (void)dismissLoadingProgress
{
}

#pragma mark- UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self performSelector:@selector(dismissLoadingProgress) withObject:self afterDelay:2];
    if (webView != self) { return; }
    
    _numRequestsLoading--;
    
    if (_numRequestsLoading == 0 && ![@"true" isEqualToString:[webView stringByEvaluatingJavaScriptFromString:@"typeof JSBridge == 'object'"]]) {
                NSString *js =   @"!function(){function init(a){var b,c;if(JSBridge._messageHandler)throw new Error('JSBridge.init called twice');for(JSBridge._messageHandler=a,b=receiveMessageQueue,receiveMessageQueue=null,c=0;c<b.length;c++)_dispatchMessageFromObjC(b[c])}function send(a,b){_doSend({data:a},b)}function registerHandler(a,b){messageHandlers[a]=b}function callHandler(a,b,c){_doSend({handlerName:a,data:b},c)}function _doSend(a,b){if(b){var c='cb_'+uniqueId++ +'_'+(new Date).getTime();responseCallbacks[c]=b,a['callbackId']=c}sendMessageQueue.push(a),alert(CUSTOM_PROTOCOL_SCHEME+'://'+QUEUE_HAS_MESSAGE)}function _fetchQueue(){var a=JSON.stringify(sendMessageQueue);return sendMessageQueue=[],a}function _dispatchMessageFromObjC(a){var d,e,f,b=JSON.parse(a);if(b.responseId){if(d=responseCallbacks[b.responseId],!d)return;d(b.responseData),delete responseCallbacks[b.responseId]}else{b.callbackId&&(e=b.callbackId,d=function(a){_doSend({responseId:e,responseData:a})}),f=JSBridge._messageHandler,b.handlerName&&(f=messageHandlers[b.handlerName]);try{f(b.data,d)}catch(g){'undefined'!=typeof console&&console.log('JSBridge: WARNING: javascript handler threw.',b,g)}}}function registerMapMethod(messageJSON){var message=JSON.parse(messageJSON);eval('window.JSBridge.'+message.handlerName+'=function(){var args={};for(var i=0;i<arguments.length;i++){args[i]=arguments[i];}return __registerMapMethod(message.handlerName,args)}')}function __registerMapMethod(a,b){var c;return callHandler(a,b,function(a){c=a}),c}function _handleMessageFromObjC(a){receiveMessageQueue?receiveMessageQueue.push(a):_dispatchMessageFromObjC(a)}var sendMessageQueue,receiveMessageQueue,messageHandlers,CUSTOM_PROTOCOL_SCHEME,QUEUE_HAS_MESSAGE,responseCallbacks,uniqueId,lf_oc_method_map,doc,readyEvent;window.JSBridge||(sendMessageQueue=[],receiveMessageQueue=[],messageHandlers={},CUSTOM_PROTOCOL_SCHEME='wvjbscheme',QUEUE_HAS_MESSAGE='__WVJB_QUEUE_MESSAGE__',responseCallbacks={},uniqueId=1,window.JSBridge={init:init,send:send,registerHandler:registerHandler,registerMapMethod:registerMapMethod,callHandler:callHandler,_fetchQueue:_fetchQueue,_handleMessageFromObjC:_handleMessageFromObjC},window.JSBridge.init(function(a,b){b(a)}),doc=document,readyEvent=doc.createEvent('Events'),readyEvent.initEvent('JSBridgeReady'),readyEvent.bridge=JSBridge,doc.dispatchEvent(readyEvent))}();";
        [webView stringByEvaluatingJavaScriptFromString:js];
    }
    
    if (_startupMessageQueue) {
        for (id queuedMessage in _startupMessageQueue) {
            [self _dispatchMessage:queuedMessage];
        }
        [_startupMessageQueue release];
        _startupMessageQueue = nil;
    }
    
    if (_startupMethodQueue) {
        for (id queueMethod in _startupMethodQueue) {
            [self _dispatchMethod:queueMethod];
        }
        [_startupMethodQueue release];
        _startupMethodQueue = nil;
    }
    
    WVJB_WEAK typeof(_webViewDelegate) strongDelegate = _webViewDelegate;
    if (strongDelegate && [strongDelegate respondsToSelector:@selector(webViewDidFinishLoad:)]) {
        [strongDelegate webViewDidFinishLoad:webView];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    if([error code] == -999){
        return;
    }
    [self dismissLoadingProgress];
    if (webView != self) { return; }
    
    _numRequestsLoading--;
    
    WVJB_WEAK typeof(_webViewDelegate) strongDelegate = _webViewDelegate;
    if (strongDelegate && [strongDelegate respondsToSelector:@selector(webView:didFailLoadWithError:)]) {
        [strongDelegate webView:webView didFailLoadWithError:error];
    }
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    if (webView != self) { return YES; }
    
    WVJB_WEAK typeof(_webViewDelegate) strongDelegate = _webViewDelegate;
    if (strongDelegate && [strongDelegate respondsToSelector:@selector(webView:shouldStartLoadWithRequest:navigationType:)]) {
        return [strongDelegate webView:webView shouldStartLoadWithRequest:request navigationType:navigationType];
    } else {
        return YES;
    }
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self showLoadingProgress];
    if (webView != self) { return; }
    
    _numRequestsLoading++;
    
    WVJB_WEAK typeof(_webViewDelegate) strongDelegate = _webViewDelegate;
    if (strongDelegate && [strongDelegate respondsToSelector:@selector(webViewDidStartLoad:)]) {
        [strongDelegate webViewDidStartLoad:webView];
    }
}

@end
