//
//  NSObject+javascript.h
//  ExampleApp-iOS
//
//  Created by YULING MINA on 14-8-13.
//  Copyright (c) 2014年 Marcus Westin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

@interface NSObject (javascript)
#pragma mark 准备知识： selector是方法名,是属于SEL类，如init、release、setObject:forKey:，message消息包括selector和方法的参数，如[dictionary setObject:obj forKey:key]，method函数包括selector和方法的具体实现，可以理解成一段可执行的代码，又叫函数，是个指针地址。
// 获取一个方法名selector的方法：
// 1、通过@selector，再通过SEL类指针指向该：SEL aSelector = @selector(doSomething:)
// 2、通过method：method_getName(method)

// 将selector转换为字符串：sel_getName(selector)

/**
 *  OC中selector转换成JS函数名
 *
 *  @param cls 类名
 *
 *  @param selector oc中selector
 *
 *  @return JS函数名
 */
+ (NSString *)selectorToJSMethod:(Class)cls selector:(SEL)selector;
+ (NSString *)methodToJSMethod:(Class)cls method:(Method)method;

/**
 *  JS函数名转换成OC selector
 *
 *  @param cls 类名
 *
 *  @param method JS函数名
 *
 *  @return OC中selector
 */
+ (SEL)jsMethodToSelector:(Class)cls method:(NSString *)jsmethod;
+ (Method)jsMethodToMethod:(Class)cls method:(NSString *)jsmethod;

/**
 *  执行方法
 *
 *  @param target   目标实例
 *  @param selector 方法
 *  @param args   参数列表
 *  @return NSString和NSNumber两种类型
 */
+ (id)obj_performSelector:(id)target selector:(SEL)selector args:(NSArray *)args;

@end
