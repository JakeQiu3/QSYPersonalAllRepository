//
//  QLKWebPageViewController.m
//  Qilekang
//
//  Created by 程显坤 on 13-7-12.
//  Copyright (c) 2013年 Qilekang. All rights reserved.
//

#import "QLKWebPageViewController.h"
#import "WebJSInterfaceCenter.h"
#import "BaseUIWebView.h"

@interface QLKWebPageViewController ()<UIScrollViewDelegate>

@property (nonatomic, strong) NSString *URLString;
@property (nonatomic, assign) BOOL isEncoding;      // 是否需要编码


@end

@implementation QLKWebPageViewController

- (id)initWithURLString:(NSString *)URLString{
    if (self = [super init]) {
        static NSString * const kAFCharactersToBeEscaped = @"?&=;+!@$()',*";
        static NSString * const kAFCharactersToLeaveUnescaped = @"[]./:#";
        
        NSString *encodeStr = (__bridge_transfer NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(
                                                                                                                    kCFAllocatorDefault,
                                                                                                                    (__bridge CFStringRef)URLString, (__bridge CFStringRef)kAFCharactersToBeEscaped, CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
        
        if ([encodeStr rangeOfString:@","].length > 0) {
            encodeStr = (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                              kCFAllocatorDefault,
                                                                                              (__bridge CFStringRef)encodeStr, (__bridge CFStringRef)kAFCharactersToLeaveUnescaped, (__bridge CFStringRef)kAFCharactersToBeEscaped, CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
        }
        
        self.isEncoding = YES;
        self.URLString = [encodeStr copy];
    }
    return self;
}

- (id)initWithURLStringWithoutEncoding:(NSString *)URLString
{
    if (self = [super init]) {
        self.isEncoding = NO;
        self.URLString = URLString;
        
    }
    
    return self;
}
//重写dealloc：当该控制器被销毁时，执行该webview为nil，对应的delegate为nil
- (void)dealloc
{
    self.webView.delegate = nil;
    [self setWebView:nil];
    //    [self.webView.scrollView removeObserver:self forKeyPath:@"contentOffset"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationView.backgroundColor = [UIColor whiteColor];
    [self setWebViewNaviLeftButton];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    self.webView = [[BaseUIWebView alloc] initWithFrame:CGRectMake(0, 64, kMainScreenFrameWitdh, kMainScreenFrameHeightWithNavigationBar)];
    
    self.webView.delegate = self;
    //     [self.webView.scrollView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    [self.view addSubview:self.webView];
    // 移除所有的urlResponsesCaches
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    if (self.isEncoding) {
        self.URLString = [self.URLString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        self.URLString = [self.URLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    
    NSURL *URL = [NSURL URLWithString:self.URLString];
    // loadRequest被重写，请查看其父类的方法
    [self.webView loadRequest:[NSURLRequest requestWithURL:URL]];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [WebJSInterfaceCenter sharedWebJSInterfaceCenter].currController = self;
}

#pragma mark 适配ios6的销毁页面的操作
- (void)viewDidUnload
{
    self.webView.delegate = nil;
    [self setWebView:nil];
    [super viewDidUnload];
}

#pragma mark creat navigationBar的2个btn method
- (void)setWebViewNaviLeftButton{
    UIImage * lpImage = [UIImage imageNamed:@"GoBack"];
    UIImage * lpImage2 = [UIImage imageByApplyingAlpha:0.5 image:lpImage];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(10, 20, 80, 44)];
    //    btn.backgroundColor = [UIColor redColor];
    [btn setImage:lpImage forState:UIControlStateNormal];
    [btn setImage:lpImage2 forState:UIControlStateHighlighted];
    btn.contentEdgeInsets = UIEdgeInsetsMake(0, -60, 0, 0);
    [btn addTarget:self action:@selector(clickBackButton:) forControlEvents:UIControlEventTouchUpInside];
    
    if(self.webView.canGoBack){
        UIButton *btn1 = [[UIButton alloc] initWithFrame:CGRectMake(20, 0, 40, 44)];
        btn1.titleLabel.font = [UIFont systemFontOfSize:15];
        [btn1 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn1 setTitle:@"关闭" forState:UIControlStateHighlighted];
        [btn1 setTitleColor:labColor_7b7b7b forState:UIControlStateNormal];
        [btn1 setTitleColor:labColor_7b7b7b forState:UIControlStateHighlighted];
        //        btn1.contentEdgeInsets = UIEdgeInsetsMake(0, -70, 0, 0);
        [btn1 addTarget:self action:@selector(clickCloseButton:) forControlEvents:UIControlEventTouchUpInside];
        [btn addSubview:btn1];
        
    }
    [self changeLeftButton:btn];
}

#pragma mark 返回和关闭btn的click methods
- (void)clickBackButton:(UIButton *)butt{
    if(IS_NOT_EMPTY(self.jsAction)){
       [self addExecuteJsActionMethod:self.jsAction];
        return;
    }
    if(self.webView.canGoBack){
        [self.webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)addExecuteJsActionMethod:(NSString *)jsValue{
    NSString *jsFunctionStr = [NSString stringWithFormat:@"window.%@()",jsValue];
    [self.webView stringByEvaluatingJavaScriptFromString:jsFunctionStr];
}
- (void)clickCloseButton:(UIButton *)butt{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark webview的delegate methods
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [ToastView showActivityAnimation];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [ToastView hideActivityAnimation];
    [self setWebViewNaviLeftButton];
    NSString *title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    if(IS_NOT_EMPTY(title)){
        self.titleLabel.text = title;
    }

}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;
}

- (void)backButtonClicked:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


//-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
//    if ([keyPath isEqualToString:@"contentOffset"]) {
//        if (self.webView.scrollView.contentSize.height - self.webView.scrollView.frame.size.height - 20 <= self.webView.scrollView.contentOffset.y) {
//            self.webView.scrollView.bounces = NO;
//        }else{
//            self.webView.scrollView.bounces = YES;
//        }
//    }
//}

@end
