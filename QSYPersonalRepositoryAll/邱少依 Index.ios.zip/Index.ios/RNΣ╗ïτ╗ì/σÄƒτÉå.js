原理：
动态配置3步：服务端获取配置，解析文件，执行native代码。
本质：服务端和客户端 protocol，来动态更新客户端的图片、颜色、字体、最多也是在原有业务逻辑或界面的基础上做删改查，而无法涉及增：业务逻辑拓展。

1、前端开发: 
HTML创建DOM，构建整个网页的布局、结构。
CSS控制DOM的样式：字体、尺寸、颜色、格式等
用JavaScript接受用户事件，动态操控的DOM。

如：动态修改一个btn ：保证html中的function必须 和 js中的function一样，要。
html中：
<button type="button" id="button369" onclick="onClick"> old button </button>
JS中的动态操控：
<script>
 function onClick() {
 	document.getElementById('button369').innerHTML='new button';
}
</script>


2、React开发：将html中的语法XML整合到了JavaScript中。JS中的XML标签不仅可以写HTML，而且可以写CSS。
// 见 style的设置宽高属性 CSS
   <View style={{top:20, left: 50, width: 50, height: 50, backgroundColor: 'powderblue'}} />

// 写HTML
 var MyComponent = React.createClass({
  handleClick: function() {
    this.refs.myTextInput.focus();
  },
  render: function() {
    return (
      <div>
        <input type="text" ref="myTextInput" />
        <input type="button" value="Focus the text input" onClick={this.handleClick} />
      </div>
    );
  }
});
这就形成了React的JSX：本质上是对 JavaScript 语法的一种拓展。


