//
//  QLKWebPageViewController.m
//  Qilekang
//
//  Created by 程显坤 on 13-7-12.
//  Copyright (c) 2013年 Qilekang. All rights reserved.
//

#import "QLKWebPageViewController.h"
#import "WebJSInterfaceCenter.h"
#import "BaseUIWebView.h"

@interface QLKWebPageViewController ()<UIScrollViewDelegate>

@property (nonatomic, strong) NSString *URLString;
@property (nonatomic, assign) BOOL isEncoding;      // 是否需要编码


@end

@implementation QLKWebPageViewController

- (id)initWithURLString:(NSString *)URLString{
    self = [super init];
    if (self) {
        static NSString * const kAFCharactersToBeEscaped = @"?&=;+!@$()',*";
        static NSString * const kAFCharactersToLeaveUnescaped = @"[]./:#";
        
        NSString *encodeStr = (__bridge_transfer NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(
                                                                                                                    kCFAllocatorDefault,
                                                                                                                    (__bridge CFStringRef)URLString, (__bridge CFStringRef)kAFCharactersToBeEscaped, CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
        
        if ([encodeStr rangeOfString:@","].length > 0) {
            encodeStr = (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                              kCFAllocatorDefault,
                                                                                              (__bridge CFStringRef)encodeStr, (__bridge CFStringRef)kAFCharactersToLeaveUnescaped, (__bridge CFStringRef)kAFCharactersToBeEscaped, CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
        }
        
        self.isEncoding = YES;
        if([encodeStr hasPrefix:@"http:"]){
            encodeStr = [encodeStr stringByReplacingOccurrencesOfString:@"http:" withString:@"https:"];
        }
        self.URLString = [encodeStr copy];

    }
    return self;
}

- (id)initWithURLStringWithoutEncoding:(NSString *)URLString
{
    if (self = [super init]) {
        self.isEncoding = NO;
        if([URLString hasPrefix:@"http:"]){
            URLString = [URLString stringByReplacingOccurrencesOfString:@"http:" withString:@"https:"];
        }
        self.URLString = URLString;
        
    }
    
    return self;
}

- (void)dealloc
{
    self.webView.delegate = nil;
    [self setWebView:nil];
    //    [self.webView.scrollView removeObserver:self forKeyPath:@"contentOffset"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationView.backgroundColor = [UIColor whiteColor];
    [self setWebViewNaviLeftButton];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    self.webView = [[BaseUIWebView alloc] initWithFrame:CGRectMake(0, 64, kMainScreenFrameWitdh, kMainScreenFrameHeightWithNavigationBar)];
    
    self.webView.delegate = self;
    //     [self.webView.scrollView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    [self.view addSubview:self.webView];
    
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    if (self.isEncoding) {
        self.URLString = [self.URLString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        self.URLString = [self.URLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    NSURL *URL = [NSURL URLWithString:self.URLString];
    [self.webView loadRequest:[NSURLRequest requestWithURL:URL]];
}

- (void)viewDidUnload
{
    self.webView.delegate = nil;
    [self setWebView:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [WebJSInterfaceCenter sharedWebJSInterfaceCenter].currController = self;
}
- (void)setWebViewNaviLeftButton{
    UIImage * lpImage = [UIImage imageNamed:@"GoBack"];
    UIImage * lpImage2 = [UIImage imageByApplyingAlpha:0.5 image:lpImage];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(10, 20, 80, 44)];
    //    btn.backgroundColor = [UIColor redColor];
    [btn setImage:lpImage forState:UIControlStateNormal];
    [btn setImage:lpImage2 forState:UIControlStateHighlighted];
    btn.contentEdgeInsets = UIEdgeInsetsMake(0, -60, 0, 0);
    [btn addTarget:self action:@selector(clickBackButton:) forControlEvents:UIControlEventTouchUpInside];
    
    if(self.webView.canGoBack){
        UIButton *btn1 = [[UIButton alloc] initWithFrame:CGRectMake(20, 0, 40, 44)];
        btn1.titleLabel.font = [UIFont systemFontOfSize:15];
        [btn1 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn1 setTitle:@"关闭" forState:UIControlStateHighlighted];
        [btn1 setTitleColor:labColor_7b7b7b forState:UIControlStateNormal];
        [btn1 setTitleColor:labColor_7b7b7b forState:UIControlStateHighlighted];
        //        btn1.contentEdgeInsets = UIEdgeInsetsMake(0, -70, 0, 0);
        [btn1 addTarget:self action:@selector(clickCloseButton:) forControlEvents:UIControlEventTouchUpInside];
        [btn addSubview:btn1];
        
    }
    [self changeLeftButton:btn];
}

- (void)clickBackButton:(UIButton *)butt{
    if(IS_NOT_EMPTY(self.jsAction)){
       [self addExecuteJsActionMethod:self.jsAction];
        return;
    }
    if(self.webView.canGoBack){
        [self.webView goBack];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)addExecuteJsActionMethod:(NSString *)jsValue{
    NSString *jsFunctionStr = [NSString stringWithFormat:@"window.%@()",jsValue];
    [self.webView stringByEvaluatingJavaScriptFromString:jsFunctionStr];
}
- (void)clickCloseButton:(UIButton *)butt{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark uiwebview 的delegate mehtods
#warning 少 该代理方法的执行顺序：先是BaseUIWebView的delegate方法，再执行其父类WebJSBridgeWebView的delegate方法，最后执行当前self的delegate方法。
- (void)webViewDidStartLoad:(UIWebView *)webView{
    NSLog(@"执行完该_cmd, 接下来会执行拦截的NSURLRequest方法");
    [ToastView showActivityAnimation];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [ToastView hideActivityAnimation];
    [self setWebViewNaviLeftButton];
    NSString *title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    if(IS_NOT_EMPTY(title)){
        self.titleLabel.text = title;
    }

}
// 重新定向URL就会执行
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"执行完该_cmd, 接下来该执行拦截的NSURLRequest方法");
    return YES;
}

- (void)backButtonClicked:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


//-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
//    if ([keyPath isEqualToString:@"contentOffset"]) {
//        if (self.webView.scrollView.contentSize.height - self.webView.scrollView.frame.size.height - 20 <= self.webView.scrollView.contentOffset.y) {
//            self.webView.scrollView.bounces = NO;
//        }else{
//            self.webView.scrollView.bounces = YES;
//        }
//    }
//}

@end
