//
//  NSObject+javascript.m
//  ExampleApp-iOS
//
//  Created by YULING MINA on 14-8-13.
//  Copyright (c) 2014年 Marcus Westin. All rights reserved.
//

#import "NSObject+javascript.h"

@implementation NSObject (javascript)

+ (NSString *)selectorToJSMethod:(Class)cls selector:(SEL)selector
{
    if (selector) {
        NSString *method_name = [NSString stringWithUTF8String:sel_getName(selector)];
        if ([method_name hasSuffix:@":"]) {
            method_name = [method_name substringToIndex:method_name.length-1];
        }
        return [method_name stringByReplacingOccurrencesOfString:@":" withString:@"_"];
    }
    
    return nil;
}

+ (NSString *)methodToJSMethod:(Class)cls method:(Method)method
{
    if (method) {
        return [NSObject selectorToJSMethod:cls selector:method_getName(method)];
    }
    
    return nil;
}

+ (SEL)jsMethodToSelector:(Class)cls method:(NSString *)jsmethod
{
    if (jsmethod) {
        // 是否存在方法
        if ([cls instancesRespondToSelector:NSSelectorFromString(jsmethod)]) {
            return NSSelectorFromString(jsmethod);
        }
        
        // 因为单一参数去掉:，此时判断是否是单一参数
        if ([cls instancesRespondToSelector:NSSelectorFromString([jsmethod stringByAppendingString:@":"])]) {
            return NSSelectorFromString([jsmethod stringByAppendingString:@":"]);
        }
        
        // 根据OC方法生成JS方法规则，参数之间':'用'_'代替
        jsmethod = [jsmethod stringByReplacingOccurrencesOfString:@"_" withString:@":"];
        if ([jsmethod rangeOfString:@":"].length > 0) {
            jsmethod = [jsmethod stringByAppendingString:@":"];
            if ([cls instancesRespondToSelector:NSSelectorFromString(jsmethod)]) {
                return NSSelectorFromString(jsmethod);
            }
        }else{
            // 是否是无参方法
            if ([cls instancesRespondToSelector:NSSelectorFromString(jsmethod)]) {
                return NSSelectorFromString(jsmethod);
            }else{
                // 根据OC方法生成JS方法规则，后一参数:删除
                jsmethod = [jsmethod stringByAppendingString:@":"];
                if ([cls instancesRespondToSelector:NSSelectorFromString(jsmethod)]) {
                    return NSSelectorFromString(jsmethod);
                }
            }
        }
    }
    
    return nil;
}

+ (Method)jsMethodToMethod:(Class)cls method:(NSString *)jsmethod
{
    SEL selector = [NSObject jsMethodToSelector:cls method:jsmethod];
    if (selector) {
        return class_getClassMethod(cls, selector);
    }
    return nil;
}

+ (id)obj_performSelector:(id)target selector:(SEL)selector args:(NSArray *)args
{
    NSMethodSignature *sig = [[target class] instanceMethodSignatureForSelector:selector];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:sig];
    [invocation setTarget:target];
    [invocation setSelector:selector];
    
    // 参数赋值
    if (args) {
        NSUInteger arg_num = sig.numberOfArguments-2;
        if ([args count] < arg_num) {
            arg_num = [args count];
        }
        for (NSUInteger i=0; i<arg_num; i++) {
            id value = [args objectAtIndex:i];
            const char *arg_type = [sig getArgumentTypeAtIndex:i+2];
            [NSObject invocation:invocation argType:arg_type argValue:value atIndex:i+2];
        }
    }
    [invocation retainArguments];
    
    // 执行函数
    [invocation invoke];
    
    // 获取返回值
//    return [NSObject invocation:invocation returnType:sig.methodReturnType];
    //获得返回值类型
    const char *returnType = sig.methodReturnType;
    //声明返回值变量
    id __unsafe_unretained returnValue;
    //如果没有返回值，也就是消息声明为void，那么returnValue=nil
    if( !strcmp(returnType, @encode(void)) ){
        returnValue =  nil;
    }
    //如果返回值为对象，那么为变量赋值
    else if( !strcmp(returnType, @encode(id)) ){
        [invocation getReturnValue:&returnValue];
    }
    else{
        //如果返回值为普通类型NSInteger  BOOL
        
        //返回值长度
        NSUInteger length = [sig methodReturnLength];
        //根据长度申请内存
        void *buffer = (void *)malloc(length);
        //为变量赋值
        [invocation getReturnValue:buffer];
        
        //以下代码为参考:具体地址我忘记了，等我找到后补上，(很对不起原作者)
        if( !strcmp(returnType, @encode(BOOL)) ) {
            returnValue = [NSNumber numberWithBool:*((BOOL*)buffer)];
        }
        else if( !strcmp(returnType, @encode(NSInteger)) ){
            returnValue = [NSNumber numberWithInteger:*((NSInteger*)buffer)];
        }
        returnValue = [NSValue valueWithBytes:buffer objCType:returnType];
    }
    
    return returnValue;
}

+ (void)invocation:(NSInvocation *)invocation argType:(const char *)arg_type argValue:(id)value atIndex:(NSUInteger)index
{
    if (strcmp(arg_type, @encode(NSString *)) == 0) {
        if ([value isKindOfClass:[NSString class]]) {
            [invocation setArgument:&value atIndex:index];
        }else if ([value respondsToSelector:@selector(stringValue)]){
            NSString *string = [value stringValue];
            [invocation setArgument:&string atIndex:index];
        }
        return;
    }
    
    if (strcmp(arg_type, @encode(int)) == 0){
        if ([value respondsToSelector:@selector(intValue)]) {
            int intValue = [value intValue];
            [invocation setArgument:&intValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(float)) == 0){
        if ([value respondsToSelector:@selector(floatValue)]) {
            float floatValue = [value floatValue];
            [invocation setArgument:&floatValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(bool)) == 0){
        if ([value respondsToSelector:@selector(boolValue)]) {
            bool boolValue = [value boolValue];
            [invocation setArgument:&boolValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(long)) == 0){
        if ([value respondsToSelector:@selector(longValue)]) {
            long longValue = [value longValue];
            [invocation setArgument:&longValue atIndex:index];
        }else if ([value respondsToSelector:@selector(integerValue)]){
            long longValue = [value integerValue];
            [invocation setArgument:&longValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(long long)) == 0){
        if ([value respondsToSelector:@selector(longLongValue)]) {
            long long longlongValue = [value longLongValue];
            [invocation setArgument:&longlongValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(unsigned int)) == 0){
        if ([value respondsToSelector:@selector(unsignedIntValue)]) {
            unsigned int uintValue = [value unsignedIntValue];
            [invocation setArgument:&uintValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(unsigned long)) == 0){
        if ([value respondsToSelector:@selector(unsignedLongValue)]) {
            unsigned long ulongValue = [value unsignedLongValue];
            [invocation setArgument:&ulongValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(unsigned long long)) == 0){
        if ([value respondsToSelector:@selector(unsignedLongLongValue)]) {
            unsigned long long ulonglongValue = [value unsignedLongLongValue];
            [invocation setArgument:&ulonglongValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(double)) == 0){
        if ([value respondsToSelector:@selector(doubleValue)]) {
            double doubleValue = [value doubleValue];
            [invocation setArgument:&doubleValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(short)) == 0){
        if ([value respondsToSelector:@selector(shortValue)]) {
            short shortValue = [value shortValue];
            [invocation setArgument:&shortValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(char)) == 0){
        if ([value respondsToSelector:@selector(charValue)]) {
            char charValue = [value charValue];
            [invocation setArgument:&charValue atIndex:index];
        }
        
    }else if (strcmp(arg_type, @encode(unsigned char)) == 0){
        if ([value respondsToSelector:@selector(unsignedCharValue)]) {
            unsigned char ucharValue = [value unsignedCharValue];
            [invocation setArgument:&ucharValue atIndex:index];
        }
    }else if (strcmp(arg_type, @encode(unsigned short)) == 0){
        if ([value respondsToSelector:@selector(unsignedShortValue)]) {
            unsigned short ushortValue = [value unsignedShortValue];
            [invocation setArgument:&ushortValue atIndex:index];
        }
    }
}

+ (id)invocation:(NSInvocation *)invocation returnType:(const char*)return_type
{
    if (strcmp(return_type, @encode(NSString *)) == 0) {
        NSString *string;
        [invocation getReturnValue:&string];
        return string;
    }else if (strcmp(return_type, @encode(int)) == 0){
        int intvalue;
        [invocation getReturnValue:&intvalue];
        return [NSNumber numberWithInt:intvalue];
    }else if (strcmp(return_type, @encode(float)) == 0){
        float floatvalue;
        [invocation getReturnValue:&floatvalue];
        return [NSNumber numberWithFloat:floatvalue];
    }else if (strcmp(return_type, @encode(bool)) == 0){
        bool boolvalue;
        [invocation getReturnValue:&boolvalue];
        return [NSNumber numberWithBool:boolvalue];
    }else if (strcmp(return_type, @encode(long)) == 0){
        long longvalue;
        [invocation getReturnValue:&longvalue];
        return [NSNumber numberWithLong:longvalue];
    }else if (strcmp(return_type, @encode(long long)) == 0){
        long long longlongvalue;
        [invocation getReturnValue:&longlongvalue];
        return [NSNumber numberWithLongLong:longlongvalue];
    }else if (strcmp(return_type, @encode(unsigned int)) == 0){
        unsigned int uintvalue;
        [invocation getReturnValue:&uintvalue];
        return [NSNumber numberWithUnsignedInt:uintvalue];
    }else if (strcmp(return_type, @encode(unsigned long)) == 0){
        unsigned long ulongvalue;
        [invocation getReturnValue:&ulongvalue];
        return [NSNumber numberWithUnsignedLong:ulongvalue];
    }else if (strcmp(return_type, @encode(unsigned long long)) == 0){
        unsigned long long ulonglongvalue;
        [invocation getReturnValue:&ulonglongvalue];
        return [NSNumber numberWithUnsignedLongLong:ulonglongvalue];
    }else if (strcmp(return_type, @encode(double)) == 0){
        double doublevalue = 0;
        [invocation getReturnValue:&doublevalue];
        return [NSNumber numberWithDouble:doublevalue];
    }else if (strcmp(return_type, @encode(short)) == 0){
        short shortvalue;
        [invocation getReturnValue:&shortvalue];
        return [NSNumber numberWithShort:shortvalue];
    }else if (strcmp(return_type, @encode(char)) == 0){
        char charvalue;
        [invocation getReturnValue:&charvalue];
        return [NSNumber numberWithChar:charvalue];
    }else if (strcmp(return_type, @encode(unsigned char)) == 0){
        unsigned char ucharvalue;
        [invocation getReturnValue:&ucharvalue];
        return [NSNumber numberWithUnsignedChar:ucharvalue];
    }else if (strcmp(return_type, @encode(unsigned short)) == 0){
        unsigned short ushortvalue;
        [invocation getReturnValue:&ushortvalue];
        return [NSNumber numberWithUnsignedShort:ushortvalue];
    }
    
    return nil;
}

@end
