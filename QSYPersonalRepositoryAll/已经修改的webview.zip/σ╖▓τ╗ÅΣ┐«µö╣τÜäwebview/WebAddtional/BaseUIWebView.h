//
//  BaseUIWebView.h
//  Qilekang
//
//  Created by Warren on 5/15/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebJSBridgeWebView.h"

@interface BaseUIWebView : WebJSBridgeWebView
@property (nonatomic, readwrite) BOOL dragReload;

- (UIScrollView *)contentScrollView;
@end

@interface UIWebView (clean)
- (void) cleanForDealloc;
@end