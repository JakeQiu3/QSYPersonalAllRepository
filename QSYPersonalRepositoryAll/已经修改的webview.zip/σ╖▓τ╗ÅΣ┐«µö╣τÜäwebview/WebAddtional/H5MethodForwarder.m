//
//  H5MethodForwarder.m
//  Qilekang
//
//  Created by Warren on 6/18/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import "H5MethodForwarder.h"

@implementation H5MethodForwarder{
}

+ (id)nativeMethod:(NSString*)msg query:(NSDictionary*)info{
    QLKDLog(@"msg=%@\ninfo=%@",msg, info);
    UIWebView* web = [info objectForKey:@"webView"];
    web = [web isKindOfClass:[UIWebView class]] ? web : nil;
    
//    msg = [msg stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    id jsonObj = [msg JSONValue];
    NSError* e = nil;
    id jsonObj = [NSJSONSerialization JSONObjectWithData:[msg dataUsingEncoding:NSUTF8StringEncoding]
                                                 options:NSJSONReadingMutableLeaves
                                                   error:&e];
    NSDictionary* dic = [jsonObj isKindOfClass:[NSDictionary class]] ? jsonObj : nil;
    NSString* methodName = [dic objectForKey:@"cmd"];
    if (methodName.length && web.window) {
        if (NSOrderedSame == [methodName caseInsensitiveCompare:@"notify"]) {
            NSDictionary* alertObj = [dic objectForKey:@"alert"];
            alertObj = [alertObj isKindOfClass:[NSDictionary class]] ? alertObj : nil;
            NSInteger type = [[alertObj objectForKey:@"type"] intValue];
//            NSInteger dur = [[alertObj objectForKey:@"dur"] intValue];
            if (1 == type) {
//                TTAlertViewController* alert = [[TTAlertViewController alloc] initWithTitle:[alertObj objectForKey:@"title"]
//                                                                                     message:[alertObj objectForKey:@"msg"]];
//                NSArray* btns = [dic objectForKey:@"btns"];
//                btns = [btns respondsToSelector:@selector(objectAtIndex:)] ? btns : nil;
//                for (__strong NSDictionary* enu in btns) {
//                    enu = [enu isKindOfClass:[NSDictionary class]] ? enu : nil;
//                    NSString* title = [enu objectForKey:@"n"];
//                    NSString* url = [enu objectForKey:@"url"];
//                    [alert addButtonWithTitle:title URL:url];
//                }
//                [alert showInView:web animated:YES];
            }
        }
        else if (NSOrderedSame == [methodName caseInsensitiveCompare:@"safari"]) {
            NSString* url = [dic objectForKey:@"url"];
            url = [url isKindOfClass:[NSString class]] ?
                [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] : nil;
            NSURL* URL = [NSURL URLWithString:url];
            if (URL) {
                [[UIApplication sharedApplication] openURL:URL];
            }
        }
        else if (NSOrderedSame == [methodName caseInsensitiveCompare:@"loadStart"]) {
//            [web startLoadingAnimation];
        }
        else if (NSOrderedSame == [methodName caseInsensitiveCompare:@"loadEnd"]) {
//            [web stopLoadingAnimation];
        }
    }
    return nil;
}

@end
