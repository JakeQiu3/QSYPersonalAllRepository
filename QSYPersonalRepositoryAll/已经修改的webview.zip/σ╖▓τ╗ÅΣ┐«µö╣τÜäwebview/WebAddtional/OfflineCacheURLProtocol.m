
//
//  OfflineCacheURLProtocol.m
//  Qilekang
//
//  Created by Warren on 5/14/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import "Reachability.h"
#import "WebCacheURLMgr.h"
#import "OfflineCacheURLProtocol.h"

#define ESCAPE_LEAK 1

#if ESCAPE_LEAK

@interface NSURLRequest(EscapeLeak)
- (id) mutableCopyEscapeLeak;
@end

@implementation NSURLRequest(EscapeLeak)
- (id) mutableCopyEscapeLeak {
    NSMutableURLRequest *mutableURLRequest = [[NSMutableURLRequest alloc] initWithURL:[self URL]
                                                                          cachePolicy:[self cachePolicy]
                                                                      timeoutInterval:[self timeoutInterval]];
    [mutableURLRequest setAllHTTPHeaderFields:[self allHTTPHeaderFields]];
    NSString *url = mutableURLRequest.URL.absoluteString;
    if([url hasPrefix:HTTP_SERVICE]){
        NSString *str = [[url componentsSeparatedByString:HTTP_SERVICE] lastObject];
        url = [NSString stringWithFormat:@"%@%@",HTTPS_SERVICE,str];
        mutableURLRequest.URL = [NSURL URLWithString:url];
    }
    if([url hasPrefix:@"http:"]){
        NSString *strUrl = [url stringByReplacingOccurrencesOfString:@"http:" withString:@"https:"];
        mutableURLRequest.URL = [NSURL URLWithString:strUrl];
    }


    
    return mutableURLRequest;
}
@end
#endif

static NSString *OfflineCacheHeader = @"X-OfflineCache";

@interface OfflineCacheURLProtocol () 
@property (nonatomic, readwrite, strong) NSURLConnection *connection;
@property (nonatomic, readwrite, strong) NSMutableData *data;
@property (nonatomic, readwrite, strong) NSURLResponse *response;
- (void)appendData:(NSData *)newData;
@end

@implementation OfflineCacheURLProtocol
@synthesize connection = _connection;
@synthesize data = _data;
@synthesize response = _response;

// 是否处理request请求:
// Url的语法格式介绍:scheme(因特网的类型)://host（主机）.domain（域名）:port（接口）/path（服务器上的路径）/filename（文件的名）
+ (BOOL)canInitWithRequest:(NSURLRequest *)request
{
  if ([@"http" isEqualToString:[[request URL] scheme]] &&
      ([request valueForHTTPHeaderField:OfflineCacheHeader] == nil)) {
    return YES;
  }
  return NO;
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request
{
  return request;
}

- (void)startLoading
{
    BOOL canUseCache = [self useCache];
    LFCacheURLData *cache = [[WebCacheURLMgr sharedWebCacheURLMgr] cacheDataForRequest:[self request]];
    if (cache) {
        NSData *data = [cache responseData];
        NSURLResponse *response = [cache httpResponse];
        NSURLRequest *redirectRequest = [cache redirectRequest];
        if (canUseCache) { // 网络满足使用缓存的条件
            if (redirectRequest) {
                [[self client] URLProtocol:self wasRedirectedToRequest:redirectRequest redirectResponse:response];
            }else{
                // 使用缓存数据
                [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
                [[self client] URLProtocol:self didLoadData:data];
                [[self client] URLProtocolDidFinishLoading:self];
            }
        }else{
            if ([[WebCacheURLMgr sharedWebCacheURLMgr] isSupportMIMETYPE:response.MIMEType]) { // 满足使用缓存的数据，比如png, jpeg等
                [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
                [[self client] URLProtocol:self didLoadData:data];
                [[self client] URLProtocolDidFinishLoading:self];
            }else{
                // 创建网络连接
                NSMutableURLRequest *connectionRequest =
#if ESCAPE_LEAK
                [[self request] mutableCopyEscapeLeak];
#else
                [[self request] mutableCopy];
#endif
                [connectionRequest setValue:@"" forHTTPHeaderField:OfflineCacheHeader];
                NSURLConnection *connection = [NSURLConnection connectionWithRequest:connectionRequest delegate:self];
                [self setConnection:connection];
            }
        }
    }else{
        // 没有缓存过数据
        if (canUseCache) {
            [[self client] URLProtocol:self didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorCannotConnectToHost userInfo:nil]];
        }else{
            // 创建网络连接
            NSMutableURLRequest *connectionRequest =
#if ESCAPE_LEAK
            [[self request] mutableCopyEscapeLeak];
#else
            [[self request] mutableCopy];
#endif
            [connectionRequest setValue:@"" forHTTPHeaderField:OfflineCacheHeader];
            NSURLConnection *connection = [NSURLConnection connectionWithRequest:connectionRequest delegate:self];
            [self setConnection:connection];
        }
    }
}

- (void)stopLoading
{
  [[self connection] cancel];
}

- (NSURLRequest *)connection:(NSURLConnection *)connection willSendRequest:(NSURLRequest *)request redirectResponse:(NSURLResponse *)response
{
    if (response == nil) {
        return request;
    }
    
    NSMutableURLRequest *redirectableRequest =
#if ESCAPE_LEAK
    [request mutableCopyEscapeLeak];
#else
    [request mutableCopy];
#endif
    [redirectableRequest setValue:nil forHTTPHeaderField:OfflineCacheHeader];

    [[WebCacheURLMgr sharedWebCacheURLMgr] URLRequest:[self request] URLRedirectRequest:redirectableRequest URLResponse:response didReceivedData:[self data]];
    [[self client] URLProtocol:self wasRedirectedToRequest:redirectableRequest redirectResponse:response];
    
    return redirectableRequest;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [[self client] URLProtocol:self didLoadData:data];
    [self appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [[self client] URLProtocol:self didFailWithError:error];
    [self setConnection:nil];
    [self setData:nil];
    [self setResponse:nil];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [self setResponse:response];
    [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [[self client] URLProtocolDidFinishLoading:self];
    [[WebCacheURLMgr sharedWebCacheURLMgr] URLRequest:[self request] URLResponse:[self response] didReceivedData:[self data]];
    
    [self setConnection:nil];
    [self setData:nil];
    [self setResponse:nil];
}

- (BOOL)useCache
{
    BOOL reachable = (BOOL) [[Reachability reachabilityWithHostName:[[[self request] URL] host]] currentReachabilityStatus] != NotReachable;
    return !reachable;
}

- (void)appendData:(NSData *)newData
{
  if ([self data] == nil) {
    [self setData:[newData mutableCopy]];
  }
  else {
    [[self data] appendData:newData];
  }
}

@end
