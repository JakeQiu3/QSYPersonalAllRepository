//
//  WebLocalStorageWriter.m
//  Qilekang
//
//  Created by Warren on 7/16/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import "WebLocalStorageWriter.h"
#import "BaseUIWebView.h"

#define H5_PATH_LSWRITE         @"html/xblank.html"
@interface WebLocalStorageWriter()<UIWebViewDelegate>
@property (nonatomic, assign) BOOL              hasLoaded;
@property (nonatomic, strong) UIWebView*        webView;
@property (nonatomic, strong) NSString*         textToWrite;
@property (nonatomic, strong) NSString*         keyToWrite;
@property (nonatomic, strong) NSString*         valueToWrite;
@property (nonatomic, copy) void(^callBack)(BOOL isSuccess, NSString* msg);
@end

@implementation WebLocalStorageWriter

- (id)init{
    return [self initWithURLString:H5_PATH_LSWRITE];
}

- (id)initWithURLString:(NSString *)urlStr
{
    if ((self = [super init])) {
        _webView = [[UIWebView alloc] initWithFrame:CGRectZero];
        _webView.delegate = self;
        _hasLoaded = NO;
        NSURL* url = [NSURL URLWithString:urlStr];
        [_webView loadHTMLString:@"" baseURL:url];
    }
    return self;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    _hasLoaded = YES;
    if (_textToWrite) {
        _callBack(YES, [self doWrite:_textToWrite]);
    } else {
        _callBack(YES, [self writeToLocalStorageForKey:_keyToWrite value:_valueToWrite]);
    }
    
    _callBack = nil;
    _textToWrite = nil;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    _callBack(NO, @"加载WEB模板出错");
    _callBack = nil;
    _textToWrite = nil;
}

- (NSString *)writeToLocalStorageForKey:(NSString *)key value:(NSString *)value
{
    NSString* jstext = [NSString stringWithFormat:@"localStorage.setItem('%@','%@')", key, value];
    return [_webView stringByEvaluatingJavaScriptFromString:jstext];
}

- (NSString*)doWrite:(NSString*)text{
    NSString* jstext = [NSString stringWithFormat:@"localStorage.setItem('cinfo','%@')", [text customBase64Encoding]];
    return [_webView stringByEvaluatingJavaScriptFromString:jstext];
}
- (void)writeKey:(NSString*)key value:(NSString *)value result:(void(^)(BOOL isSuccess, NSString* msg))callback
{
    __block WebLocalStorageWriter* selfholder = self;
    if (_hasLoaded) {
        callback(YES, [self writeToLocalStorageForKey:key value:value]);
    }else {
        _keyToWrite = key;
        _valueToWrite = value;
        _callBack = ^(BOOL isSuccess, NSString* msg){
            callback(isSuccess, msg);
            selfholder = nil;
        };
    }
}
- (void)write:(NSString*)text result:(void(^)(BOOL isSuccess, NSString* msg))callback{
    __block WebLocalStorageWriter* selfholder = self;
    if (_hasLoaded) {
        callback(YES, [self doWrite:text]);
    }else {
        _textToWrite = text;
        _callBack = ^(BOOL isSuccess, NSString* msg){
            callback(isSuccess, msg);
            selfholder = nil;
        };
    }
}

- (void)dealloc{
    [self.webView stopLoading];
    self.webView.delegate = nil;
}
@end
