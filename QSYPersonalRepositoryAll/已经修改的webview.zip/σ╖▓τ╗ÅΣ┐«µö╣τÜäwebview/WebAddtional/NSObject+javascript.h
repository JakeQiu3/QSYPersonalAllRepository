//
//  NSObject+javascript.h
//  ExampleApp-iOS
//
//  Created by YULING MINA on 14-8-13.
//  Copyright (c) 2014年 Marcus Westin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

@interface NSObject (javascript)

/**
 *  OC中selector转换成JS函数名
 *
 *  @param cls 类名
 *
 *  @param selector oc中selector
 *
 *  @return JS函数名
 */
+ (NSString *)selectorToJSMethod:(Class)cls selector:(SEL)selector;
+ (NSString *)methodToJSMethod:(Class)cls method:(Method)method;

/**
 *  JS函数名转换成OCselector
 *
 *  @param cls 类名
 *
 *  @param method JS函数名
 *
 *  @return OC中selector
 */
+ (SEL)jsMethodToSelector:(Class)cls method:(NSString *)jsmethod;
+ (Method)jsMethodToMethod:(Class)cls method:(NSString *)jsmethod;

/**
 *  执行方法OC方法
 *
 *  @param target   目标实例
 *  @param selector 方法
 *  @param args   参数列表
 *  @return NSString和NSNumber两种类型
 */
+ (id)obj_performSelector:(id)target selector:(SEL)selector args:(NSArray *)args;

@end
