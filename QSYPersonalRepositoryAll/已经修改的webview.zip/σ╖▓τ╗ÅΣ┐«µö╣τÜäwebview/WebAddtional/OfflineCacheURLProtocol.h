
//
//  OfflineCacheURLProtocol.h
//  Qilekang
//
//  Created by Warren on 5/14/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OfflineCacheURLProtocol : NSURLProtocol

@end
