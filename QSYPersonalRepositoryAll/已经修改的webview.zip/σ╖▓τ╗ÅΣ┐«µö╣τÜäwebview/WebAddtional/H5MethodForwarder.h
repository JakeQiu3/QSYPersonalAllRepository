//
//  H5MethodForwarder.h
//  Qilekang
//
//  Created by Warren on 6/18/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface H5MethodForwarder : NSObject<UIAlertViewDelegate>

@end
