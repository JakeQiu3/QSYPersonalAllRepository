//
//  WebJSBridgeWebView.h
//  Qilekang
//
//  Created by wj on 14-7-7.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//

#import <UIKit/UIKit.h>

#define JS_2_OC_NOTIFY @"JS_2_OC_NOTIFY" // POST消息
#define JS_2_OC_KEY @"JS_2_OC_KEY" // 方法名
#define JS_2_OC_PARAM @"JS_2_OC_PARAM" // 参数

#define kCustomProtocolScheme @"wvjbscheme"
#define kQueueHasMessage      @"__WVJB_QUEUE_MESSAGE__"

typedef void (^WVJBResponseCallback)(id responseData);
typedef void (^WVJBHandler)(id data, WVJBResponseCallback responseCallback);

@interface WebJSBridgeWebView : UIWebView<UIWebViewDelegate>

+ (void)enableLogging;

#pragma mark- message
- (void)send:(id)message;
- (void)send:(id)message responseCallback:(WVJBResponseCallback)responseCallback;
- (void)registerHandler:(NSString*)handlerName handler:(WVJBHandler)handler;
- (void)callHandler:(NSString*)handlerName;
- (void)callHandler:(NSString*)handlerName data:(id)data;
- (void)callHandler:(NSString*)handlerName data:(id)data responseCallback:(WVJBResponseCallback)responseCallback;

#pragma mark- call js method
- (void)callClass:(NSString *)className handler:(NSString *)handlerName;
- (void)callClass:(NSString *)className handler:(NSString *)handlerName data:(id)data;
- (void)callClass:(NSString *)className handler:(NSString *)handlerName data:(id)data responseCallback:(WVJBResponseCallback)responseCallback;

#pragma mark- method
/**
 *  向JS注册方法
 *
 *  @param methodName 方法名
 *  @param handler    OC处理回调，data：js调用函数的参数列表，responseCallback：OC处理完返回给JS的值
 */
- (void)registerMethod:(NSString *)methodName handler:(WVJBHandler)handler;

#pragma mark- reset
- (void)reset;

- (void)setWebJSHandler:(WVJBHandler)handler;

- (void)showLoadingProgress;
- (void)dismissLoadingProgress;
@end
