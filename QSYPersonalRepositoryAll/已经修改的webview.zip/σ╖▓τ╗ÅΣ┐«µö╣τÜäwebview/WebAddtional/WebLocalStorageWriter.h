//
//  WebLocalStorageWriter.h
//  Qilekang
//
//  Created by Warren on 7/16/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebLocalStorageWriter : NSObject

- (id)initWithURLString:(NSString *)urlStr;
- (void)write:(NSString*)text result:(void(^)(BOOL isSucess, NSString* msg))callback;
- (void)writeKey:(NSString*)key value:(NSString *)value result:(void(^)(BOOL isSuccess, NSString* msg))callback;

@end
