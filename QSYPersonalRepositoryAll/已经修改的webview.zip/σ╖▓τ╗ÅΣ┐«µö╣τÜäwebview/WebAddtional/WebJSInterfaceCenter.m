//
//  WebJSInterfaceCenter.m
//  Qilekang
//
//  Created by YULING MINA on 14-8-12.
//  Copyright (c) 2014年 Qilekang. All rights reserved.
//
#import "NSObject+javascript.h"
#import "WebJSInterfaceCenter.h"
#import "QLKWebPageViewController.h"
#import "QLKBI.h"
#import <AdSupport/AdSupport.h>
//========================== 非注册方法封装 =======================================
@implementation LFJSInterfaceProtocol

- (NSArray *)registerJSMethodArray
{
    return [NSArray array];
}

- (NSString *)invokeJSMethod:(NSString *)method params:(NSDictionary *)params
{
    return nil;
}

@end
//=================================================================

//============================ 空白单例 =====================================
#pragma mark- 空白单利
@interface BlankSingleSton : NSObject
CWL_DECLARE_SINGLETON_FOR_CLASS(BlankSingleSton)
@end
@implementation BlankSingleSton
CWL_SYNTHESIZE_SINGLETON_FOR_CLASS(BlankSingleSton)
@end
//=================================================================

@implementation WebJSInterfaceCenter{
    NSString *alertUrl;
    BOOL isChange;
    UIButton *rightButton;// 新增的右侧Btn
}
CWL_SYNTHESIZE_SINGLETON_FOR_CLASS(WebJSInterfaceCenter)

// 注册可供JS调用的方法
- (NSArray *)registerJSMethodArray
{
    if(self.jsMethodArr && self.jsMethodArr.count > 0){
        return self.jsMethodArr;
    }
    NSMutableArray *array = [NSMutableArray array];
    
    // WebJSInterfaceCenter 类方法
    unsigned int method_count;
    Method *method_list = class_copyMethodList([self class], &method_count);
    for (unsigned int i=0; i<method_count; i++) {
        NSString *method_name = [NSObject methodToJSMethod:[self class] method:method_list[i]];
        if (method_name) {
            [array addObject:method_name];
        }
    }
    free(method_list);
    
    // 删除非注册方法
    method_list = class_copyMethodList([LFJSInterfaceProtocol class], &method_count);
    for (unsigned int i=0; i<method_count; i++) {
        NSString *method_name = [NSObject methodToJSMethod:[LFJSInterfaceProtocol class] method:method_list[i]];
        if ([array containsObject:method_name]) {
            [array removeObject:method_name];
        }
    }
    free(method_list);
    
    // 删除无关方法
    method_list = class_copyMethodList([BlankSingleSton class], &method_count);
    for (unsigned int i=0; i<method_count; i++) {
        NSString *method_name = [NSObject methodToJSMethod:[BlankSingleSton class] method:method_list[i]];
        if ([array containsObject:method_name]) {
            [array removeObject:method_name];
        }
    }
    free(method_list);
    self.jsMethodArr = array;
    return array;
}
// JS调用OC需要执行的方法
- (NSString *)invokeJSMethod:(NSString *)method params:(NSDictionary *)params
{
    // 回调处理
    NSMutableArray *args = [NSMutableArray array];
    if (params) {
        NSUInteger num = params.count;
        for (NSUInteger i=0; i<num; i++) {
            id object = [params objectForKey:[NSString stringWithFormat:@"%d", (int)i]];
            if (object) {
                if ([object isKindOfClass:[NSString class]]) {
                    [args addObject:object];
                }else if ([object isKindOfClass:[NSDictionary class]]
                          || [object isKindOfClass:[NSArray class]]){
                    [args addObject:[object JSONString]];
                }else if ([object respondsToSelector:@selector(description)]){
                    [args addObject:[object description]];
                }
            }
        }
    }
    
    id result;
    @try {
        SEL selector = [NSObject jsMethodToSelector:[WebJSInterfaceCenter class] method:method];
        result = [NSObject obj_performSelector:[WebJSInterfaceCenter sharedWebJSInterfaceCenter] selector:selector args:args];
    }
    @catch (NSException *exception) {
        QLKDLog(@"WebJSInterfaceCenter: WARNING: objc selector threw. %@", exception);
    }
    return result;
}



// 获取系统信息方法
#pragma mark sysInfo
/**
 *  获取APP信息
 */
- (NSString *)getAppInfo{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:1];
    //应用名称
    NSBundle*bundle =[NSBundle mainBundle];
    NSDictionary*info =[bundle infoDictionary];
    NSString*prodName =[info objectForKey:@"CFBundleName"];
    [dic setObject:prodName forKey:@"appName"];
    
    //设备型号
    [dic setObject:STORE_VERSION forKey:@"appVersion"];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return  json;
}
/**
 *  获取设备信息
 *
 *  @return 设备信息
 */
- (NSString *)getSysInfo{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:1];
    //平台
    [dic setObject:@"1" forKey:@"platformName"];
    //系统版本
    [dic setObject:[NSString stringWithFormat:@"%.2f",SYSTEM_VERSION] forKey:@"platformVersion"];
    //设备型号
    [dic setObject:[NSString getDeviceName] forKey:@"model"];
    //设备ID
    [dic setObject:[[ASIdentifierManager sharedManager] advertisingIdentifier].UUIDString forKey:@"divceId"];
    //mac地址
    [dic setObject:[[ASIdentifierManager sharedManager] advertisingIdentifier].UUIDString forKey:@"mac"];
    // h5的域名 0 代表线上环境,  1 代表开发环境,  2 代表预发布环境 3 代表测试环境
    [dic setObject:KAPI_H5_Environmental forKey:@"realms"];
    // 新增H5的版本号
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    docPath = [docPath stringByAppendingPathComponent:@"Crow5"];
    NSString *configPath=[docPath stringByAppendingPathComponent:@"crow5/config"];
    NSData *configData=[NSData dataWithContentsOfFile:configPath];
    NSDictionary *configDic=[NSJSONSerialization JSONObjectWithData:configData options:NSJSONReadingMutableContainers error:nil];
    if (configDic && IS_NOT_EMPTY([configDic objectForKey:@"h5_v"])) {
        [dic setObject:[NSString stringWithFormat:@"%.1f",[[configDic objectForKey:@"h5_v"] floatValue]] forKey:@"nv"];
    }
    //网络状态
    [dic setObject:S(SharedAppDelegate.netStatus) forKey:@"netType"];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return  json;
}

/**
 *  获取用户信息
 *
 *  @return 用户信息
 */
-(NSString *)getUserInfo{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:1];
    [dic setObject:QLK_UserId forKey:@"userId"];
    if(IS_NOT_EMPTY(QLK_UserName)){
        [dic setObject:[QLK_UserName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] forKey:@"userName"];
    }
    if(IS_NOT_EMPTY(QLK_UserImg)){
        [dic setObject:QLK_UserImg forKey:@"userImg"];
    }
    [dic setObject:QLK_Token forKey:@"userToken"];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return  json;
}

/**
 *  设置webtitle
 *
 *  @param title 标题
 */
-(void)setPageTitle:(NSString *)title{
    NSDictionary *dic = [title objectFromJSONString];
    NSString *mainTitle = dic[@"mainTitle"];
    NSString *assistantTitle = dic[@"assistantTitle"];
    if(IS_NOT_EMPTY(assistantTitle)){
        //        self.currController.titleLabel.text =  [NSString stringWithFormat:@"%@/n%@"];
    } else {
        self.currController.titleLabel.text =  mainTitle;
    }
    
}

/**
 *  页面跳转
 *
 *  @param key 页面协议
 */
-(void)webToAppPage:(NSString *)json{
    
    [QLKPageManage appPageJump:json];
}
/**
 *  提示
 *
 *  @param json 提示信息内容
 */
-(void)appAlert:(NSString *)json{
    NSData *jsonData = [json dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    NSString *content = [dic objectForKey:@"content"];
    NSString *title = [dic objectForKey:@"title"];
    NSString *cancelButt = [dic objectForKey:@"cancelButt"];
    NSString *anctionButt = [dic objectForKey:@"actionButt"];
    NSString *actionUrl = [dic objectForKey:@"actionUrl"];
    NSString *code = [NSString stringWithFormat:@"%lld",[[dic objectForKey:@"code"] longLongValue]];
    if ([code isEqualToString:@"1"]||[code isEqualToString:@"40006"]) {
        NSDictionary *tempDic=[NSDictionary dictionaryWithObjectsAndKeys:code,@"code",content,@"msg", nil];
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:tempDic options:0 error:nil];
        KXJson *kxjson=[KXJson jsonWithJsonString:[[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding]];
        NSDictionary *dic = [NSDictionary dictionaryWithObject:kxjson forKey:@"KXJson"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"QLKLoginViewController" object:nil userInfo:dic];
        return ;
    }
    
    //强制更新跟新提示
    if([@"40038" isEqualToString:code]){
        NSDictionary *dic = @{@"K":@"updateAppVersion"
                              };
        [QLKPageManage appPageJump:[dic JSONString]];
        [ToastView hideActivityAnimation];
        return ;
    }
    //h5升级code == 30989 的时候让h5去升级 返回首页 重新调用首页api
    if ([@"40039" isEqualToString:code]) {
        [[NSNotificationCenter defaultCenter]postNotificationName:kCheckH5ConfigVersion object:nil];
        [ToastView hideActivityAnimation];
        return;
    }
    
    if(IS_NOT_EMPTY(content)){
        if ([@"" isEqualToString:cancelButt]) {
            cancelButt=nil;
        }
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:content delegate:self cancelButtonTitle:anctionButt otherButtonTitles:cancelButt, nil];
        if(IS_NOT_EMPTY(actionUrl)){
            alert.delegate = self;
            alertUrl = actionUrl;
        }
        [alert show];
    }
    
}
/**
 *  吐丝
 *
 *  @param mes 内容
 */
- (void)showToast:(NSString *)mes{
    if(IS_NOT_EMPTY(mes)){
        [ToastView showMessageCaption:mes];
        
    }
    
}

/**
 *  退出登录
 */
- (void)appLogOut{
    AppDelegate* delegate = kAppDelegate;
    [delegate logOut];
}

/**
 *  开始动画
 */
- (void)startLoadView{
    [ToastView showActivityAnimation];
}
/**
 *  结束动画
 */
- (void)stopLoadView{
    [ToastView hideActivityAnimation];
}
/**
 *  获取公告已读内容记录
 *
 *  @param topic 公告类型
 *
 *  @return 已读记录数
 */
- (NSString *)getNoticeRecord:(NSString *)topic{
    topic =   [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@appNotice%@",QLK_UserId,topic]];
    if(IS_NOT_EMPTY(topic)){
        return topic;
    }
    return @"0";
}
/**
 *  设置公告记录
 *
 *  @param json topic 公告类型  num 记录数
 *
 */
- (void)setNoticeRecord:(NSString *)json{
    NSData *jsonData = [json dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        return ;
    }
    NSString *topic = [dic objectForKey:@"topic"];
    NSString *time = [dic objectForKey:@"time"];
    if(IS_NOT_EMPTY(topic) && IS_NOT_EMPTY(time)){
        [[NSUserDefaults standardUserDefaults] setObject:time forKey:[NSString stringWithFormat:@"%@webNotice%@",QLK_UserId,topic]];
    }
}

/**
 *  JS发送BI
 *
 *  @param json 这只有data
 */
-(void)sendBIWithJson:(NSString *)json{
    KXJson* kxJson = [KXJson jsonWithJsonString:json];

    NSString * jsonstr = json;
    NSString *b = [jsonstr substringToIndex:1];
    if (json&&json.length>1&&[b isEqualToString:@"E"]) {
        [QLKBiStatistics apidActionString:json];
    }else{
        if ([kxJson.json isKindOfClass:[NSDictionary class]]) {
            [QLKBI event:kxJson.json];
        }
    }
    
    
    
}

/**
 *  分享
 *
 */
- (void)shareAction:(NSString *)json{
    [QLKPageManage appPageJump:json];
}
/**
 *  设置右上角按钮
 *""
 *  @param json {"title":"按钮","linkUrl":"url"}
 */
- (void)addRightButt:(NSString *)json{
    if(IS_NOT_EMPTY(json)){
        NSDictionary *dic = [json objectFromJSONString];
        NSString *title = [dic objectForKey:@"name"];
        NSString *type = [dic objectForKey:@"type"];
        NSString *linkUrl = [dic objectForKey:@"url"];
        NSString *imageName = [dic objectForKey:@"imageName"];
        if ([self.currController.navigationView.subviews containsObject:rightButton]) {
            [rightButton removeFromSuperview];
            rightButton = nil;
        }
        rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"shareNotice" object:nil userInfo:dic];
        
        [rightButton addTarget:self action:@selector(clickRightButton:) forControlEvents:UIControlEventTouchUpInside];
        if (imageName) {
            NSDictionary * urlDic=[dic objectForKey:@"url"];
            rightButton.frame = CGRectMake(kMainScreenFrameWitdh - 50 , 20, 50, 44);
            NSString *folderPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
            folderPath = [folderPath stringByAppendingPathComponent:@"Crow5/crow5"];
            NSString *filePath = [NSString stringWithFormat:@"%@%@", folderPath,imageName];
            UIImage *image = [UIImage imageWithContentsOfFile:filePath];
            //需要固定图片大小才不失真
            UIImageView * imageView=[[UIImageView alloc]initWithFrame:CGRectMake(kMainScreenFrameWitdh - 35, 33, 18, 18)];
            imageView.image=image;
            imageView.userInteractionEnabled=YES;
            [self.currController.navigationView addSubview:imageView];
            [rightButton addTarget:self action:@selector(clickRightButton:) forControlEvents:UIControlEventTouchUpInside];
            [self.currController.navigationView addSubview:rightButton];
            NSString * dicUrl=[urlDic JSONString];
            objc_setAssociatedObject(rightButton, @"rightNavButt",[NSString stringWithFormat:@"%@*%@",type,dicUrl], OBJC_ASSOCIATION_RETAIN);
        }else{
            objc_setAssociatedObject(rightButton, @"rightNavButt",[NSString stringWithFormat:@"%@*%@",type,linkUrl], OBJC_ASSOCIATION_RETAIN);
            [rightButton setTitleColor: labColor_7b7b7b forState:UIControlStateNormal];
            CGSize textSize = [title sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:16.0f], NSFontAttributeName, nil]];
            rightButton.frame = CGRectMake( SCREEN_WIDTH - (textSize.width+40), 25, textSize.width+40, textSize.height+10);
            [rightButton setTitle:title forState:UIControlStateNormal];
            rightButton.titleLabel.font=[UIFont systemFontOfSize:15];
            if (IS_NOT_EMPTY(title)) {
                [self.currController.navigationView addSubview:rightButton];
            }
        }
    }
}

/**
 *  设置app缓存
 *
 *  @param json key value
 */
- (void)setAppCache:(NSString *)json{
    if(IS_NOT_EMPTY(json)){
        NSDictionary *dic = [json objectFromJSONString];
        [[NSUserDefaults standardUserDefaults] setObject:dic[@"value"] forKey:dic[@"key"]];
    }
}
/**
 *  获取app缓存
 *
 *  @param key key
 *
 *  @return value
 */
- (NSString *)getAppCache:(NSString *)key{
    if(IS_NOT_EMPTY(key)){
        
        return [[NSUserDefaults standardUserDefaults] objectForKey:key];
    }else{
        return @"";
    }
}
/**
 *  删除app缓存
 *
 *  @param key key
 */
- (void)removeAppCache:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
}
/**
 *  获取城市列表
 *
 *
 *  @return value
 */
- (NSString *)getCityList{
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    docPath = [docPath stringByAppendingPathComponent:cityAndDepmentsFile];
    //    获取城市和科室的文件路径
    NSString *cityPath = [docPath stringByAppendingPathComponent:@"/citesList.plist"];
    NSArray *cityArr = [[NSArray alloc] initWithContentsOfFile:cityPath];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:cityArr options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonStr;
}

/**
 *  获取科室信息
 *
 *
 *  @return value
 */
- (NSString *)getDepartments {
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    docPath = [docPath stringByAppendingPathComponent:cityAndDepmentsFile];
    NSString *departmentsPath = [docPath stringByAppendingPathComponent:@"/depList.plist"];
    NSArray *departmentArr = [[NSArray alloc] initWithContentsOfFile:departmentsPath];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:departmentArr options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonStr;
}
/**
 *  获取定位信息
 *
 *
 *  @return value
 */
- (NSString *)getLocationCity {
    NSMutableDictionary *locationDic = [kAppUserdefaults objectForKey:UserLocationInfo];
    if (!([locationDic count]>0)) {
        [locationDic setObject:@"" forKey:@"province"];
        [locationDic setObject:@"" forKey:@"city"];
        [locationDic setObject:@"" forKey:@"district"];
        [locationDic setObject:@"" forKey:@"address"];
        [locationDic setObject:@"" forKey:@"longitude"];
        [locationDic setObject:@"" forKey:@"latitude"];
    }
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:locationDic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return json;
}

- (void)clickRightButton:(UIButton *)butt{
    NSString * userInfo = objc_getAssociatedObject(butt, @"rightNavButt");
    NSArray *arr = [userInfo componentsSeparatedByString:@"*"];
    if(arr.count > 1){
        NSInteger type = [[arr objectAtIndex:0] integerValue];
        if(type == 1){
            [QLKPageManage appPageJump:[arr objectAtIndex:1]];
        }else{
            QLKWebPageViewController *currWebView =  (QLKWebPageViewController*)self.currController;
            NSString *jsFucktion = [NSString stringWithFormat:@"window.%@()",[arr objectAtIndex:1]];
            UIWebView *web = (UIWebView*)currWebView.webView;
            [web stringByEvaluatingJavaScriptFromString:jsFucktion];
        }
    }else if(arr.count > 0){
        [QLKPageManage appPageJump:[arr objectAtIndex:0]];
    }
}

#pragma mark alertDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){
        [QLKPageManage appPageJump:alertUrl];
    }
}
/**
 *  获取取消预约内容
 *
 */
- (NSString *)getCancelDetailList{
    NSArray * array=[QLKUser sharedInstance].cancelDetailList;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonStr;
}

/**
 * 我的医生指导提示信息
 * @param json {"page":"mydoctor" , "height":"123","marginLeft":"234"} height、marginLeft单位px
 */
- (void)showHtml5Help:(NSString *)json{
    if (IS_NOT_EMPTY(json)) {
        NSDictionary *dic = [json objectFromJSONString];
        NSString * page = [dic objectForKey:@"page"];
        NSString * height=@"";
        if ([dic objectForKey:@"height"]) {
            if ([[dic objectForKey:@"height"] isEqual:[NSString class]]) {
                height = [dic objectForKey:@"height"];
            }else{
                height = [[dic objectForKey:@"height"] stringValue];
            }
        }
        
        NSString * doctorSize =[NSString stringWithFormat:@"%@",height];
        NSDictionary * shujuDic=[NSDictionary dictionaryWithObjectsAndKeys:page,@"K",doctorSize,@"V", nil];
        NSString * jsonStr=[shujuDic JSONString];
        [QLKPageManage appPageJump:jsonStr];
    }
}

/**
 *  页面标识
 *
 *  @param string viewId  页面标识
 */
- (void)setCurrViewId:(NSString *)viewId{
    NSString * shangyiyeId =[NSString stringWithFormat:@"%@",[QLKUser sharedInstance].currentPage];
    [QLKUser sharedInstance].previousPage = shangyiyeId;
    [QLKUser sharedInstance].currentPage = viewId;
}

/**
 * 获取账户余额
 *
 *
 *  @return 返回账户的余额
 */
- (NSString *)getPrice {
    NSString *balance = [kAppUserdefaults objectForKey:@"UserBalance"];
    if(IS_NOT_EMPTY(balance)){
        return balance;
    }
    return @"0.00";
}

@end
