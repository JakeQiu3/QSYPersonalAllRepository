//
//  WebHttpProtocol.m
//  Qilekang
//
//  Created by Warren on 5/14/13.
//  Copyright (c) 2013 Qilekang. All rights reserved.
//

#import "WebHttpProtocol.h"
#import "WebJSInterfaceCenter.h"

static NSArray* kLocalJSs = nil;

@implementation WebHttpProtocol
// NSURLProtocol作为抽象类，它的子类可以用来： 拦截处理网络请求.具体见1234。

// 拦截的原理：苹果URL加载采用的是URL加载系统，该系统中有很多处理URL请求的类譬如：NSURL，NSURLRequest，NSURLConnection和NSURLSession等, 当URL Loading System(URL加载系统)使用NSURLRequest,它会创建一个NSURLProtocol子类的实例。

// 1、重定向网络请求
// 2、忽略网络请求，使用本地缓存
// 3、自定义网络请求的返回结果
// 4、一些全局的网络请求设置

// 是否打算处理对应的request
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    // 获取该request的 request.allHTTPHeaderFields
    //    {
    //        Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
    //        "User-Agent" = "Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13F69";
    //    }
    NSString* UA = [request.allHTTPHeaderFields objectForKey:@"User-Agent"];//它是一个特殊字符串头，使得服务器能够识别客户使用的操作系统及版本、CPU 类型、浏览器及版本、浏览器渲染引擎、浏览器语言、浏览器插件等
    if (![@"GET" isEqualToString:request.HTTPMethod]
        || [UA rangeOfString:@"AppleWebKit"].location == NSNotFound) {
        return NO;
    }
    
    NSString *pathString = [[request URL] absoluteString];
    if (!kLocalJSs) {
        if (!kLocalJSs) {
            kLocalJSs = @[@"echarts-all.min.js"];
        }
    }
    BOOL ret = NO;
    for (NSString *name in kLocalJSs) {
        if ([pathString hasSuffix:name]) {
            ret = YES;
            break;
        }
    }
    return ret ? ret : [super canInitWithRequest:request];
}

- (void) startLoading {
    id<NSURLProtocolClient> client = [self client];
    NSURLRequest* request = [self request];
    NSString *pathString = [[request URL] absoluteString];
    NSData* data = nil;
    if ([pathString hasSuffix:@"JSBridge.js"]) {
        NSString *jsFileContent =  @"!function(){function init(a){var b,c;if(JSBridge._messageHandler)throw new Error('JSBridge.init called twice');for(JSBridge._messageHandler=a,b=receiveMessageQueue,receiveMessageQueue=null,c=0;c<b.length;c++)_dispatchMessageFromObjC(b[c])}function send(a,b){_doSend({data:a},b)}function registerHandler(a,b){messageHandlers[a]=b}function callHandler(a,b,c){_doSend({handlerName:a,data:b},c)}function _doSend(a,b){if(b){var c='cb_'+uniqueId++ +'_'+(new Date).getTime();responseCallbacks[c]=b,a['callbackId']=c}sendMessageQueue.push(a),alert(CUSTOM_PROTOCOL_SCHEME+'://'+QUEUE_HAS_MESSAGE)}function _fetchQueue(){var a=JSON.stringify(sendMessageQueue);return sendMessageQueue=[],a}function _dispatchMessageFromObjC(a){var d,e,f,b=JSON.parse(a);if(b.responseId){if(d=responseCallbacks[b.responseId],!d)return;d(b.responseData),delete responseCallbacks[b.responseId]}else{b.callbackId&&(e=b.callbackId,d=function(a){_doSend({responseId:e,responseData:a})}),f=JSBridge._messageHandler,b.handlerName&&(f=messageHandlers[b.handlerName]);try{f(b.data,d)}catch(g){'undefined'!=typeof console&&console.log('JSBridge: WARNING: javascript handler threw.',b,g)}}}function registerMapMethod(messageJSON){var message=JSON.parse(messageJSON);eval('window.JSBridge.'+message.handlerName+'=function(){var args={};for(var i=0;i<arguments.length;i++){args[i]=arguments[i];}return __registerMapMethod(message.handlerName,args)}')}function __registerMapMethod(a,b){var c;return callHandler(a,b,function(a){c=a}),c}function _handleMessageFromObjC(a){receiveMessageQueue?receiveMessageQueue.push(a):_dispatchMessageFromObjC(a)}var sendMessageQueue,receiveMessageQueue,messageHandlers,CUSTOM_PROTOCOL_SCHEME,QUEUE_HAS_MESSAGE,responseCallbacks,uniqueId,lf_oc_method_map,doc,readyEvent;window.JSBridge||(sendMessageQueue=[],receiveMessageQueue=[],messageHandlers={},CUSTOM_PROTOCOL_SCHEME='wvjbscheme',QUEUE_HAS_MESSAGE='__WVJB_QUEUE_MESSAGE__',responseCallbacks={},uniqueId=1,window.JSBridge={init:init,send:send,registerHandler:registerHandler,registerMapMethod:registerMapMethod,callHandler:callHandler,_fetchQueue:_fetchQueue,_handleMessageFromObjC:_handleMessageFromObjC},window.JSBridge.init(function(a,b){b(a)}),doc=document,readyEvent=doc.createEvent('Events'),readyEvent.initEvent('JSBridgeReady'),readyEvent.bridge=JSBridge,doc.dispatchEvent(readyEvent))}();";
        // 生成JS代码
        NSMutableString *jsString = [NSMutableString stringWithString:@";"];
        NSArray *method_array = [[WebJSInterfaceCenter sharedWebJSInterfaceCenter] registerJSMethodArray];
        for (NSString *method in method_array) {
            [jsString appendFormat:@"eval(\'window.JSBridge.%@=function(){var args={};for(var i=0;i<arguments.length;i++){args[i]=arguments[i];}return __registerMapMethod(\\'%@\\', args)}');", method, method];
        }
        // 插入JS代码
        jsFileContent = [jsFileContent stringByReplacingOccurrencesOfString:@"var lf_oc_method_map;" withString:jsString];
        data = [jsFileContent dataUsingEncoding:NSUTF8StringEncoding];
    }else{
        for (NSString *name in kLocalJSs) {
            if ([pathString hasSuffix:name]) {
                NSString *folderPath  = [[NSBundle mainBundle] pathForResource:[@"Crow5/" stringByAppendingString:name] ofType:nil];
                data = [NSData dataWithContentsOfFile:folderPath];
                break;
            }
        }
    }
    
    if (data) {
        NSHTTPURLResponse* response = [[NSHTTPURLResponse alloc] initWithURL:[request URL]
                                                                  statusCode:200
                                                                 HTTPVersion:@"HTTP/1.1"
                                                                headerFields:[NSDictionary dictionary]];
        [client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
        [client URLProtocol:self didLoadData:data];
        [client URLProtocolDidFinishLoading:self];
    }
    else {
        [super startLoading];
    }
}
@end
