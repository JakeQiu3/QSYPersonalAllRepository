## Counter Example

#### React-Native 0.32.0 & Redux 3.5.2 & React-Redux 4.4.5

This repo demonstrates the usage of latest React-Native with Redux.

### Usage

- you have to use `npm@3.x`, if you are using `npm@2.x` you might get into some wired scenarios. Please open an issue if you can't get it run on `npm@2.x`. also you can follow this [issue](https://github.com/rackt/react-redux/issues/236) for more info.
- clone the project
- go to `Counter` folder
- run `npm install`

Cheers,
