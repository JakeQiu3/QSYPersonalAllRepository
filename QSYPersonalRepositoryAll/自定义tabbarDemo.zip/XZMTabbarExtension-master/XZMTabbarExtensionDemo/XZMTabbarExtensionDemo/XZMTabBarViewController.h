
//
//  Created by 谢忠敏 on 15/7/22.
//  Copyright (c) 2015年 谢忠敏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZMTabBarViewController : UITabBarController

@end
