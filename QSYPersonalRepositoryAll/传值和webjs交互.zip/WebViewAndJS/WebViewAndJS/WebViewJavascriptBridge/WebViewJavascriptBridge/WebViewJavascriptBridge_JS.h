#import <Foundation/Foundation.h>
// 待注入的JS方法：需提前注入
NSString * WebViewJavascriptBridge_js();
